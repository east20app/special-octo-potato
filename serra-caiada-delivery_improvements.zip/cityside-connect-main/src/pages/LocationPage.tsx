import { useState } from "react";
import { MapPin, Navigation, Search, ChevronRight, Loader2, AlertTriangle, Home } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const LocationPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [blocked, setBlocked] = useState(false);

  // Manual address fields (client address)
  const [street, setStreet] = useState("");
  const [number, setNumber] = useState("");
  const [complement, setComplement] = useState("");
  const [reference, setReference] = useState("");
  const [neighborhood, setNeighborhood] = useState("");

  const { data: serviceArea } = useQuery({
    queryKey: ["service-area"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("city_service_areas")
        .select("*")
        .eq("is_active", true)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const neighborhoods = serviceArea?.neighborhoods || [];
  const filtered = neighborhoods.filter((n: string) =>
    n.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const clearLocation = () => {
    localStorage.removeItem("user_lat");
    localStorage.removeItem("user_lng");
    localStorage.removeItem("user_neighborhood");
    localStorage.removeItem("user_cep");
    localStorage.removeItem("location_mode");
    localStorage.removeItem("user_city");
    localStorage.removeItem("user_state");

    // manual address extras
    localStorage.removeItem("user_street");
    localStorage.removeItem("user_number");
    localStorage.removeItem("user_complement");
    localStorage.removeItem("user_reference");
  };

  const setLocationStorage = (mode: "gps" | "manual", extra: Record<string, string>) => {
    clearLocation();
    localStorage.setItem("location_mode", mode);
    localStorage.setItem("user_city", "Serra Caiada");
    localStorage.setItem("user_state", "RN");
    Object.entries(extra).forEach(([k, v]) => localStorage.setItem(k, v));
  };

  const handleGPS = async () => {
    setLoading(true);
    setBlocked(false);
    if (!navigator.geolocation) {
      toast.error("GPS não disponível neste dispositivo");
      setLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        if (serviceArea?.center_lat != null && serviceArea?.center_lng != null) {
          const dist = getDistanceKm(
            latitude, longitude,
            serviceArea.center_lat!, serviceArea.center_lng!
          );
          if (dist > (serviceArea.radius_km || 15)) {
            setBlocked(true);
            toast.error(`Serviço disponível apenas em ${serviceArea.city_name} – ${serviceArea.state}`);
            setLoading(false);
            return;
          }
        }
        setLocationStorage("gps", {
          user_lat: String(latitude),
          user_lng: String(longitude),
        });
        toast.success("Localização detectada!");
        navigate("/");
        setLoading(false);
      },
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          toast.error("Permissão de localização negada. Use a seleção manual.");
        } else if (err.code === err.TIMEOUT) {
          toast.error("Tempo esgotado ao obter localização. Tente novamente.");
        } else {
          toast.error("Não foi possível obter sua localização.");
        }
        setLoading(false);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const selectNeighborhood = (name: string) => {
    setNeighborhood(name);
    // Keep user on the page so they can fill the full address.
    toast.message(`Bairro selecionado: ${name}`);
  };

  const saveManualAddress = () => {
    if (!neighborhood) {
      toast.error("Selecione um bairro válido");
      return;
    }
    if (!street.trim()) {
      toast.error("Informe a rua do endereço");
      return;
    }
    setLocationStorage("manual", {
      user_neighborhood: neighborhood,
      user_street: street.trim(),
      user_number: number.trim(),
      user_complement: complement.trim(),
      user_reference: reference.trim(),
    });
    toast.success("Endereço salvo!");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground px-4 pt-12 pb-8 rounded-b-3xl">
        <h1 className="text-2xl font-extrabold">Onde você está?</h1>
        <p className="text-sm opacity-80 mt-1">Precisamos saber para mostrar lojas perto de você</p>
      </header>

      <div className="px-4 py-6 space-y-4">
        {blocked && (
          <div className="bg-destructive/10 border border-destructive/20 rounded-2xl p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-destructive">Fora da área de atendimento</p>
              <p className="text-xs text-muted-foreground mt-1">
                Serviço disponível apenas em Serra Caiada – RN. Selecione um bairro abaixo.
              </p>
            </div>
          </div>
        )}

        <Button onClick={handleGPS} disabled={loading} className="w-full h-14 rounded-2xl text-base gap-3">
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Navigation className="w-5 h-5" />}
          Usar minha localização (GPS)
        </Button>

        <div className="relative">
          <div className="flex items-center justify-center gap-3 py-3">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs text-muted-foreground">ou escolha seu bairro</span>
            <div className="h-px flex-1 bg-border" />
          </div>
        </div>

        {/* Manual address */}
        <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Home className="w-5 h-5 text-primary" />
            <h2 className="font-extrabold">Endereço do cliente</h2>
          </div>
          <p className="text-xs text-muted-foreground">
            Informe um endereço dentro de Serra Caiada – RN. Esse endereço é usado para calcular entrega e localizar o cliente.
          </p>

          <div className="grid grid-cols-1 gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar bairro..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 rounded-xl"
              />
            </div>

            <Input
              placeholder="Rua (ex: Av. João Pessoa)"
              value={street}
              onChange={(e) => setStreet(e.target.value)}
              className="rounded-xl"
            />

            <div className="grid grid-cols-2 gap-2">
              <Input
                placeholder="Número (ex: 120)"
                value={number}
                onChange={(e) => setNumber(e.target.value)}
                className="rounded-xl"
              />
              <Input
                placeholder="Complemento (opcional)"
                value={complement}
                onChange={(e) => setComplement(e.target.value)}
                className="rounded-xl"
              />
            </div>

            <Input
              placeholder="Referência (opcional)"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              className="rounded-xl"
            />

            <Button onClick={saveManualAddress} className="w-full rounded-2xl h-12 font-extrabold">
              Salvar endereço
            </Button>

            {neighborhood && (
              <p className="text-xs text-muted-foreground">
                Bairro selecionado: <span className="font-semibold text-foreground">{neighborhood}</span>
              </p>
            )}
          </div>
        </div>

        <div className="space-y-1">
          {filtered.map((n: string) => (
            <button
              key={n}
              onClick={() => selectNeighborhood(n)}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-card hover:bg-accent transition-colors"
            >
              <span className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">{n}</span>
              </span>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          ))}
          {filtered.length === 0 && searchQuery && (
            <p className="text-center text-sm text-muted-foreground py-6">
              Bairro não encontrado na área de atendimento
            </p>
          )}
          {filtered.length === 0 && !searchQuery && neighborhoods.length === 0 && (
            <p className="text-center text-sm text-muted-foreground py-6">
              Carregando bairros...
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

function getDistanceKm(lat1: number, lng1: number, lat2: number, lng2: number) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export default LocationPage;
