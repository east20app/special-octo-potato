import { useParams, Link } from "react-router-dom";
import { ArrowLeft, CheckCircle2, Clock, ChefHat, Package, Truck } from "lucide-react";

const steps = [
  { key: "received", label: "Pedido recebido", icon: CheckCircle2 },
  { key: "preparing", label: "Preparando", icon: ChefHat },
  { key: "ready", label: "Pronto", icon: Package },
  { key: "out_for_delivery", label: "Saiu para entrega", icon: Truck },
  { key: "delivered", label: "Entregue", icon: CheckCircle2 },
];

const OrderTrackingPage = () => {
  const { orderId } = useParams();
  // TODO: fetch real order + realtime subscription
  const currentStep = 1; // mock

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/" className="p-2 -ml-2">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-lg font-bold">Acompanhar pedido</h1>
      </header>

      <div className="px-6 py-8">
        <div className="bg-card rounded-2xl p-6 shadow-sm">
          <h2 className="font-bold text-lg mb-6">Status do pedido</h2>
          <div className="space-y-0">
            {steps.map((step, idx) => {
              const isActive = idx <= currentStep;
              const Icon = step.icon;
              return (
                <div key={step.key} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        isActive
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    {idx < steps.length - 1 && (
                      <div
                        className={`w-0.5 h-8 ${
                          isActive ? "bg-primary" : "bg-muted"
                        }`}
                      />
                    )}
                  </div>
                  <div className="pt-2">
                    <p
                      className={`text-sm font-semibold ${
                        isActive ? "text-foreground" : "text-muted-foreground"
                      }`}
                    >
                      {step.label}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 bg-card rounded-2xl p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Pedido #{orderId?.slice(0, 8)}</p>
          <div className="flex items-center gap-2 mt-2 text-sm">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <span>Tempo estimado: ~35 min</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderTrackingPage;
