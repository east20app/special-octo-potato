import { ShieldX } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const UnauthorizedPage = () => (
  <div className="min-h-screen flex flex-col items-center justify-center bg-background px-6 text-center">
    <ShieldX className="w-16 h-16 text-destructive mb-4" />
    <h1 className="text-2xl font-extrabold mb-2">Acesso não autorizado</h1>
    <p className="text-muted-foreground mb-6">
      Você não tem permissão para acessar esta página.
    </p>
    <Link to="/">
      <Button className="rounded-xl">← Voltar ao início</Button>
    </Link>
  </div>
);

export default UnauthorizedPage;
