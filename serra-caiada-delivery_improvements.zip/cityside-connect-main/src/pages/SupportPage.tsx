import { ArrowLeft, MessageCircle, Phone, Mail } from "lucide-react";
import { Link } from "react-router-dom";

const SupportPage = () => {
  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/perfil" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Suporte</h1>
      </header>

      <div className="px-4 py-6 space-y-4">
        <div className="bg-card rounded-2xl p-6 text-center">
          <MessageCircle className="w-12 h-12 mx-auto mb-3 text-primary" />
          <h2 className="text-lg font-bold">Precisa de ajuda?</h2>
          <p className="text-sm text-muted-foreground mt-1">Entre em contato conosco</p>
        </div>

        <a href="https://wa.me/5584999999999" target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-4 bg-card p-4 rounded-xl hover:bg-accent transition-colors">
          <div className="w-10 h-10 rounded-full bg-success/10 flex items-center justify-center"><Phone className="w-5 h-5 text-success" /></div>
          <div>
            <h3 className="font-bold text-sm">WhatsApp</h3>
            <p className="text-xs text-muted-foreground">Fale conosco pelo WhatsApp</p>
          </div>
        </a>

        <a href="mailto:suporte@serracaiada.app"
          className="flex items-center gap-4 bg-card p-4 rounded-xl hover:bg-accent transition-colors">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center"><Mail className="w-5 h-5 text-primary" /></div>
          <div>
            <h3 className="font-bold text-sm">Email</h3>
            <p className="text-xs text-muted-foreground">suporte@serracaiada.app</p>
          </div>
        </a>
      </div>
    </div>
  );
};

export default SupportPage;
