import { ArrowLeft, Heart } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";

const FavoritesPage = () => {
  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: favorites, isLoading } = useQuery({
    queryKey: ["favorites", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("favorites")
        .select("*, stores(id, name, banner_url, rating, delivery_fee, avg_prep_time_min, neighborhood, is_open, categories(name, icon))")
        .eq("user_id", session!.user.id);
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/perfil" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Favoritos</h1>
      </header>

      <div className="px-4 py-4 space-y-3">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="w-full h-28 rounded-2xl" />)
        ) : !favorites || favorites.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Heart className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Nenhum favorito ainda</p>
            <p className="text-sm mt-1">Favorite lojas para encontrá-las aqui</p>
          </div>
        ) : (
          favorites.map((fav) => {
            const store = fav.stores as any;
            if (!store) return null;
            return (
              <Link key={fav.id} to={`/loja/${store.id}`}
                className="bg-card rounded-2xl p-3 flex gap-3 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-20 h-20 rounded-xl bg-muted shrink-0 overflow-hidden">
                  {store.banner_url ? (
                    <img src={store.banner_url} alt={store.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-3xl">{store.categories?.icon || "🏪"}</div>
                  )}
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-sm">{store.name}</h3>
                  <p className="text-xs text-muted-foreground">{store.categories?.name} • {store.neighborhood}</p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                    {Number(store.rating) > 0 && <span className="text-warning font-bold">⭐ {Number(store.rating).toFixed(1)}</span>}
                    <span>🕐 {store.avg_prep_time_min} min</span>
                  </div>
                </div>
              </Link>
            );
          })
        )}
      </div>
    </div>
  );
};

export default FavoritesPage;
