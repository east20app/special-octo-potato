import { useState, useEffect } from "react";
import { ArrowLeft, MapPin, CreditCard, Banknote, QrCode, Loader2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const CheckoutPage = () => {
  const navigate = useNavigate();
  const [selectedPayment, setSelectedPayment] = useState<"pix" | "card" | "cash">("pix");
  const [couponCode, setCouponCode] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [isPickup, setIsPickup] = useState(false);

  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => {
      const { data } = await supabase.auth.getSession();
      return data.session;
    },
  });

  const { data: cart } = useQuery({
    queryKey: ["user-cart", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("carts")
        .select("*, cart_items(*, products(name, price, image_url))")
        .eq("user_id", session!.user.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: addresses } = useQuery({
    queryKey: ["user-addresses", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("addresses")
        .select("*")
        .eq("user_id", session!.user.id)
        .order("is_default", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: store } = useQuery({
    queryKey: ["checkout-store", cart?.store_id],
    enabled: !!cart?.store_id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stores")
        .select("*")
        .eq("id", cart!.store_id)
        .single();
      if (error) throw error;
      return data;
    },
  });

  const [selectedAddress, setSelectedAddress] = useState<string | null>(null);

  useEffect(() => {
    if (addresses && addresses.length > 0 && !selectedAddress) {
      const def = addresses.find((a) => a.is_default);
      setSelectedAddress(def?.id || addresses[0].id);
    }
  }, [addresses, selectedAddress]);

  const items = (cart as any)?.cart_items || [];
  const subtotal = items.reduce((acc: number, item: any) => acc + Number(item.unit_price) * item.quantity, 0);
  const deliveryFee = isPickup ? 0 : Number(store?.delivery_fee || 0);
  const total = subtotal + deliveryFee;

  const handleOrder = async () => {
    if (!session?.user?.id) { toast.error("Faça login primeiro"); navigate("/auth"); return; }
    if (!cart || items.length === 0) { toast.error("Carrinho vazio"); return; }
    if (!isPickup && !selectedAddress) { toast.error("Selecione um endereço"); return; }

    setSubmitting(true);
    try {
      const { data: order, error: orderErr } = await supabase
        .from("orders")
        .insert({
          user_id: session.user.id,
          store_id: cart.store_id,
          address_id: isPickup ? null : selectedAddress,
          subtotal,
          delivery_fee: deliveryFee,
          total,
          payment_method: selectedPayment,
          notes,
          is_pickup: isPickup,
          status: "pending",
        })
        .select()
        .single();
      if (orderErr) throw orderErr;

      const orderItems = items.map((item: any) => ({
        order_id: order.id,
        product_id: item.product_id,
        product_name: item.products?.name || "Produto",
        quantity: item.quantity,
        unit_price: item.unit_price,
        addons: item.addons,
        notes: item.notes,
      }));
      const { error: itemsErr } = await supabase.from("order_items").insert(orderItems);
      if (itemsErr) throw itemsErr;

      await supabase.from("payments").insert({
        order_id: order.id,
        method: selectedPayment,
        amount: total,
        status: selectedPayment === "cash" ? "pending" : "pending",
      });

      // Clear cart
      await supabase.from("cart_items").delete().eq("cart_id", cart.id);
      await supabase.from("carts").delete().eq("id", cart.id);

      toast.success("Pedido realizado com sucesso!");
      navigate(`/pedido/${order.id}`);
    } catch (err: any) {
      toast.error(err.message || "Erro ao criar pedido");
    } finally {
      setSubmitting(false);
    }
  };

  if (!session) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center">
        <p className="text-lg font-bold mb-4">Faça login para continuar</p>
        <Link to="/auth"><Button className="rounded-xl">Entrar</Button></Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-32">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/carrinho" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Finalizar pedido</h1>
      </header>

      <div className="px-4 py-4 space-y-5">
        {/* Delivery or Pickup */}
        <section>
          <h2 className="font-bold text-sm mb-2">Tipo de entrega</h2>
          <div className="flex gap-2">
            <button onClick={() => setIsPickup(false)}
              className={`flex-1 py-3 rounded-xl text-sm font-medium border transition-colors ${!isPickup ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
              🛵 Delivery
            </button>
            <button onClick={() => setIsPickup(true)}
              className={`flex-1 py-3 rounded-xl text-sm font-medium border transition-colors ${isPickup ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
              🏪 Retirada
            </button>
          </div>
        </section>

        {/* Address */}
        {!isPickup && (
          <section>
            <h2 className="font-bold text-sm mb-2">Endereço de entrega</h2>
            {addresses && addresses.length > 0 ? (
              <div className="space-y-2">
                {addresses.map((addr) => (
                  <button key={addr.id} onClick={() => setSelectedAddress(addr.id)}
                    className={`w-full text-left p-3 rounded-xl border transition-colors ${selectedAddress === addr.id ? "border-primary bg-accent" : "border-border bg-card"}`}>
                    <p className="text-sm font-semibold">{addr.label}</p>
                    <p className="text-xs text-muted-foreground">{addr.street}, {addr.number} - {addr.neighborhood}</p>
                  </button>
                ))}
              </div>
            ) : (
              <Link to="/enderecos" className="block p-3 rounded-xl border border-dashed border-border text-center text-sm text-primary">
                <MapPin className="w-5 h-5 mx-auto mb-1" /> Adicionar endereço
              </Link>
            )}
          </section>
        )}

        {/* Payment */}
        <section>
          <h2 className="font-bold text-sm mb-2">Forma de pagamento</h2>
          <div className="space-y-2">
            {[
              { value: "pix" as const, label: "PIX", icon: QrCode, desc: "Pague na hora" },
              { value: "card" as const, label: "Cartão", icon: CreditCard, desc: "Crédito ou débito" },
              { value: "cash" as const, label: "Dinheiro", icon: Banknote, desc: "Pague na entrega" },
            ].map((pm) => (
              <button key={pm.value} onClick={() => setSelectedPayment(pm.value)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-colors ${selectedPayment === pm.value ? "border-primary bg-accent" : "border-border bg-card"}`}>
                <pm.icon className="w-5 h-5 text-primary" />
                <div className="text-left">
                  <p className="text-sm font-semibold">{pm.label}</p>
                  <p className="text-xs text-muted-foreground">{pm.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Notes */}
        <section>
          <h2 className="font-bold text-sm mb-2">Observações</h2>
          <Textarea placeholder="Alguma observação para o pedido?" value={notes} onChange={(e) => setNotes(e.target.value)}
            className="rounded-xl" rows={2} />
        </section>

        {/* Summary */}
        <section className="bg-card rounded-2xl p-4 space-y-2">
          <h2 className="font-bold text-sm mb-2">Resumo</h2>
          {items.map((item: any) => (
            <div key={item.id} className="flex justify-between text-sm">
              <span>{item.quantity}x {item.products?.name || "Item"}</span>
              <span>R$ {(Number(item.unit_price) * item.quantity).toFixed(2)}</span>
            </div>
          ))}
          <div className="border-t border-border pt-2 mt-2 space-y-1">
            <div className="flex justify-between text-sm"><span>Subtotal</span><span>R$ {subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between text-sm"><span>Frete</span><span>{deliveryFee === 0 ? "Grátis" : `R$ ${deliveryFee.toFixed(2)}`}</span></div>
            <div className="flex justify-between font-bold text-base pt-1"><span>Total</span><span className="text-primary">R$ {total.toFixed(2)}</span></div>
          </div>
        </section>
      </div>

      {/* Confirm */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-card border-t border-border z-40">
        <Button onClick={handleOrder} disabled={submitting} className="w-full h-14 rounded-2xl text-base font-bold">
          {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : `Confirmar pedido • R$ ${total.toFixed(2)}`}
        </Button>
      </div>
    </div>
  );
};

export default CheckoutPage;
