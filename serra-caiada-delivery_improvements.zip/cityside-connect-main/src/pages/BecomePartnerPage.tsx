import { useState } from "react";
import { ArrowLeft, Store, TrendingUp, Users, BarChart3, Loader2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import Footer from "@/components/Footer";
import { useAuth } from "@/hooks/useAuth";

const BecomePartnerPage = () => {
  const navigate = useNavigate();
  const { user, isLoading: authLoading } = useAuth();
  const [form, setForm] = useState({ name: "", type: "food" as "food" | "market", phone: "", neighborhood: "", description: "" });
  const [submitting, setSubmitting] = useState(false);

  // Check existing store
  const { data: existingStore, isLoading: storeLoading } = useQuery({
    queryKey: ["my-store-application", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stores")
        .select("id, name, is_approved, created_at")
        .eq("owner_id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const handleSubmit = async () => {
    if (!form.name || !form.phone) {
      toast.error("Preencha o nome da loja e WhatsApp");
      return;
    }
    if (!user) {
      toast.error("Faça login primeiro");
      navigate("/auth");
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from("stores").insert({
        owner_id: user.id,
        name: form.name,
        mode: form.type === "food" ? "food" : "market",
        phone: form.phone,
        neighborhood: form.neighborhood,
        description: form.description,
        is_approved: false,
        is_active: true,
        is_open: false,
        city: "Serra Caiada",
        state: "RN",
      });
      if (error) throw error;
      toast.success("Loja cadastrada! Aguarde a aprovação do administrador.");
      navigate("/");
    } catch (err: any) {
      toast.error(err.message || "Erro ao cadastrar");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Seja um Parceiro</h1>
      </header>

      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground px-6 py-10 text-center">
        <Store className="w-16 h-16 mx-auto mb-4" />
        <h2 className="text-2xl font-extrabold">Venda mais com delivery</h2>
        <p className="text-sm opacity-90 mt-2 max-w-md mx-auto">Cadastre sua loja ou restaurante e alcance mais clientes em Serra Caiada</p>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {[
            { icon: TrendingUp, title: "Aumente suas vendas", desc: "Alcance novos clientes sem sair do lugar", color: "text-success" },
            { icon: Users, title: "Mais visibilidade", desc: "Sua loja aparece para todos na cidade", color: "text-primary" },
            { icon: BarChart3, title: "Painel completo", desc: "Gerencie pedidos, produtos e relatórios", color: "text-warning" },
          ].map((b) => (
            <div key={b.title} className="bg-card rounded-2xl p-5 text-center shadow-sm">
              <b.icon className={`w-8 h-8 mx-auto mb-2 ${b.color}`} />
              <h3 className="font-bold text-sm">{b.title}</h3>
              <p className="text-xs text-muted-foreground mt-1">{b.desc}</p>
            </div>
          ))}
        </div>

        <div className="bg-card rounded-2xl p-5 mb-8">
          <h3 className="font-bold mb-3">Tipos de loja aceitos</h3>
          <div className="grid grid-cols-2 gap-3">
            {["🍔 Restaurantes e lanchonetes", "🛒 Mercados e mercearias", "💊 Farmácias", "🍺 Bebidas", "🐾 Pet shops", "📦 Conveniência", "💧 Água e gás", "🎂 Doces e confeitaria"].map((t) => (
              <span key={t} className="text-sm text-muted-foreground">{t}</span>
            ))}
          </div>
        </div>

        <div className="bg-secondary/10 border border-secondary/20 rounded-2xl p-5 mb-8 text-center">
          <p className="text-xs text-secondary font-bold uppercase">Comissão da plataforma</p>
          <p className="text-3xl font-extrabold text-secondary mt-1">10% - 15%</p>
          <p className="text-xs text-muted-foreground mt-1">por pedido, negociável conforme volume</p>
        </div>

        {/* Existing store status */}
        {existingStore && (
          <div className="bg-card rounded-2xl p-6 mb-8 border border-border">
            <h3 className="font-bold mb-2">Sua loja: {existingStore.name}</h3>
            <p className={`font-bold ${existingStore.is_approved ? "text-success" : "text-warning"}`}>
              {existingStore.is_approved ? "Aprovada ✅" : "Aguardando aprovação"}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Cadastrada em {new Date(existingStore.created_at).toLocaleDateString("pt-BR")}
            </p>
            {existingStore.is_approved && (
              <Link to="/painel" className="inline-block mt-3">
                <Button className="rounded-xl">Ir para o painel</Button>
              </Link>
            )}
          </div>
        )}

        {/* Form */}
        {!existingStore && (
          <div className="bg-card rounded-2xl p-6">
            <h3 className="font-bold mb-4">Cadastre sua loja</h3>
            <div className="space-y-3">
              <Input placeholder="Nome da loja / restaurante" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <Select value={form.type} onValueChange={(v: any) => setForm({ ...form, type: v })}>
                <SelectTrigger><SelectValue placeholder="Tipo de loja" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="food">🍔 Comida (restaurante, lanchonete)</SelectItem>
                  <SelectItem value="market">🛒 Loja (mercado, farmácia, etc.)</SelectItem>
                </SelectContent>
              </Select>
              <Input placeholder="WhatsApp (84) 99999-9999" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              <Input placeholder="Bairro em Serra Caiada" value={form.neighborhood} onChange={(e) => setForm({ ...form, neighborhood: e.target.value })} />
              <Textarea placeholder="Descreva sua loja (opcional)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} />

              {!user && !authLoading ? (
                <Link to="/auth">
                  <Button className="w-full rounded-xl h-12">Fazer login para se cadastrar</Button>
                </Link>
              ) : (
                <Button onClick={handleSubmit} disabled={submitting} className="w-full rounded-xl h-12">
                  {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Enviar cadastro"}
                </Button>
              )}
              <p className="text-xs text-muted-foreground text-center">Após o envio, o admin vai analisar e aprovar sua loja.</p>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default BecomePartnerPage;
