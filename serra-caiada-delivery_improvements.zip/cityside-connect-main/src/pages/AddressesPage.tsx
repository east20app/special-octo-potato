import { useState } from "react";
import { ArrowLeft, Plus, MapPin, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const AddressesPage = () => {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ label: "Casa", street: "", number: "", neighborhood: "", zip_code: "" });

  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: addresses, isLoading } = useQuery({
    queryKey: ["addresses", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase.from("addresses").select("*").eq("user_id", session!.user.id).order("is_default", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const addMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("addresses").insert({
        user_id: session!.user.id,
        ...form,
        is_default: !addresses || addresses.length === 0,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["addresses"] });
      toast.success("Endereço adicionado!");
      setOpen(false);
      setForm({ label: "Casa", street: "", number: "", neighborhood: "", zip_code: "" });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("addresses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["addresses"] });
      toast.success("Endereço removido");
    },
  });

  const setDefault = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from("addresses").update({ is_default: false }).eq("user_id", session!.user.id);
      const { error } = await supabase.from("addresses").update({ is_default: true }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["addresses"] });
      toast.success("Endereço padrão atualizado");
    },
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/perfil" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
          <h1 className="text-lg font-bold">Endereços</h1>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="rounded-xl gap-1"><Plus className="w-4 h-4" /> Novo</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Novo endereço</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <Input placeholder="Rótulo (Casa, Trabalho)" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} />
              <Input placeholder="Rua" value={form.street} onChange={(e) => setForm({ ...form, street: e.target.value })} />
              <div className="flex gap-2">
                <Input placeholder="Número" value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} />
                <Input placeholder="CEP" value={form.zip_code} onChange={(e) => setForm({ ...form, zip_code: e.target.value })} />
              </div>
              <Input placeholder="Bairro" value={form.neighborhood} onChange={(e) => setForm({ ...form, neighborhood: e.target.value })} />
              <Button onClick={() => addMutation.mutate()} disabled={!form.street || !form.neighborhood} className="w-full rounded-xl">
                Salvar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </header>

      <div className="px-4 py-4 space-y-3">
        {isLoading ? null : !addresses || addresses.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <MapPin className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Nenhum endereço cadastrado</p>
          </div>
        ) : (
          addresses.map((addr) => (
            <div key={addr.id} className={`bg-card rounded-xl p-4 border ${addr.is_default ? "border-primary" : "border-border"}`}>
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm">{addr.label}</h3>
                    {addr.is_default && <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full font-bold">Padrão</span>}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{addr.street}, {addr.number} - {addr.neighborhood}</p>
                </div>
                <div className="flex gap-1">
                  {!addr.is_default && (
                    <button onClick={() => setDefault.mutate(addr.id)} className="text-xs text-primary font-medium px-2 py-1">Padrão</button>
                  )}
                  <button onClick={() => deleteMutation.mutate(addr.id)} className="p-1 text-destructive"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AddressesPage;
