import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

const TermsPage = () => (
  <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
      <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
      <h1 className="text-lg font-bold">Termos de uso</h1>
    </header>
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-card rounded-2xl p-6 prose prose-sm max-w-none">
        <h2 className="text-lg font-bold">Termos de Uso - SC Delivery</h2>
        <p className="text-sm text-muted-foreground mt-3">Última atualização: Fevereiro 2026</p>
        <h3 className="font-bold mt-4 mb-2">1. Aceitação dos Termos</h3>
        <p className="text-sm text-muted-foreground">Ao utilizar a plataforma SC Delivery, você concorda com estes termos de uso. O serviço está disponível exclusivamente para a cidade de Serra Caiada - RN.</p>
        <h3 className="font-bold mt-4 mb-2">2. Cadastro e Conta</h3>
        <p className="text-sm text-muted-foreground">O usuário deve fornecer informações verdadeiras e manter seus dados atualizados. É proibido criar contas falsas ou compartilhar credenciais.</p>
        <h3 className="font-bold mt-4 mb-2">3. Pedidos e Pagamentos</h3>
        <p className="text-sm text-muted-foreground">Os pedidos são intermediados pela plataforma. Os preços são definidos pelas lojas parceiras. Aceitamos PIX, cartão e dinheiro na entrega.</p>
        <h3 className="font-bold mt-4 mb-2">4. Entrega</h3>
        <p className="text-sm text-muted-foreground">Os prazos são estimativas e podem variar. A plataforma não se responsabiliza por atrasos causados por condições externas.</p>
        <h3 className="font-bold mt-4 mb-2">5. Cancelamentos</h3>
        <p className="text-sm text-muted-foreground">Cancelamentos podem ser feitos antes da confirmação da loja. Após o preparo, podem haver taxas de cancelamento.</p>
      </div>
    </div>
    <Footer />
  </div>
);

export default TermsPage;
