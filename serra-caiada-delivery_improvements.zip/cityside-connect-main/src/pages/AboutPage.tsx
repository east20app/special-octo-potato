import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

const AboutPage = () => (
  <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
      <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
      <h1 className="text-lg font-bold">Sobre nós</h1>
    </header>
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
      <div className="bg-card rounded-2xl p-6">
        <h2 className="text-xl font-extrabold mb-3">🛵 SC Delivery</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Somos a plataforma de delivery local de Serra Caiada - RN. Conectamos restaurantes, mercados, farmácias e lojas da nossa cidade com você, oferecendo praticidade, rapidez e os melhores preços.
        </p>
      </div>
      <div className="bg-card rounded-2xl p-6">
        <h3 className="font-bold mb-2">Nossa missão</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Facilitar o acesso dos moradores de Serra Caiada aos produtos e serviços locais, fortalecendo o comércio da nossa cidade e gerando renda para entregadores e lojistas.
        </p>
      </div>
      <div className="bg-card rounded-2xl p-6">
        <h3 className="font-bold mb-2">Como funciona</h3>
        <ul className="text-sm text-muted-foreground space-y-2">
          <li>📱 Escolha uma loja ou restaurante</li>
          <li>🛒 Adicione itens ao carrinho</li>
          <li>💳 Pague com PIX, cartão ou dinheiro</li>
          <li>🛵 Receba em casa ou retire no local</li>
        </ul>
      </div>
    </div>
    <Footer />
  </div>
);

export default AboutPage;
