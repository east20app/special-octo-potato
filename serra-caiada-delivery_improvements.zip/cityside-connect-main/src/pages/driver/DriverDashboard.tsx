import { useState } from "react";
import { Link } from "react-router-dom";
import { Navigation, Package, Clock, DollarSign, Power } from "lucide-react";
import { Button } from "@/components/ui/button";

const DriverDashboard = () => {
  const [isAvailable, setIsAvailable] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-foreground text-background px-6 pt-10 pb-6 rounded-b-3xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-wider opacity-60">Painel</p>
            <h1 className="text-2xl font-extrabold">Entregador</h1>
          </div>
          <button
            onClick={() => setIsAvailable(!isAvailable)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold transition-colors ${
              isAvailable
                ? "bg-success text-success-foreground"
                : "bg-muted text-muted-foreground"
            }`}
          >
            <Power className="w-4 h-4" />
            {isAvailable ? "Online" : "Offline"}
          </button>
        </div>
      </header>

      {/* Stats */}
      <div className="px-4 py-6 grid grid-cols-3 gap-3">
        {[
          { label: "Hoje", value: "R$ 0", icon: DollarSign },
          { label: "Entregas", value: "0", icon: Package },
          { label: "Tempo médio", value: "0 min", icon: Clock },
        ].map((stat) => (
          <div key={stat.label} className="bg-card rounded-2xl p-4 text-center shadow-sm">
            <stat.icon className="w-5 h-5 mx-auto text-muted-foreground mb-1" />
            <p className="text-lg font-extrabold">{stat.value}</p>
            <p className="text-[10px] text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Available deliveries */}
      <div className="px-4">
        <h2 className="text-lg font-bold mb-3">Entregas disponíveis</h2>
        {isAvailable ? (
          <div className="text-center py-10 text-muted-foreground">
            <Navigation className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Nenhuma entrega no momento</p>
            <p className="text-sm">Novas entregas aparecerão aqui</p>
          </div>
        ) : (
          <div className="bg-accent rounded-2xl p-6 text-center">
            <p className="text-sm font-medium text-accent-foreground">
              Fique <strong>Online</strong> para receber entregas
            </p>
          </div>
        )}
      </div>

      <div className="px-4 mt-6">
        <Link to="/" className="text-sm text-primary font-medium">
          ← Voltar ao site
        </Link>
      </div>
    </div>
  );
};

export default DriverDashboard;
