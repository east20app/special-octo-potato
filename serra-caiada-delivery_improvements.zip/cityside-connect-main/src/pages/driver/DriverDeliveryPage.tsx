import { useParams, Link } from "react-router-dom";
import { ArrowLeft, MapPin, ExternalLink } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

const statusFlow = ["accepted", "picked_up", "delivered"] as const;
const statusLabels: Record<string, string> = {
  accepted: "Aceita", picked_up: "Coletado", delivered: "Entregue", cancelled: "Cancelada",
};

const DriverDeliveryPage = () => {
  const { deliveryId } = useParams();
  const queryClient = useQueryClient();

  const { data: delivery } = useQuery({
    queryKey: ["delivery", deliveryId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deliveries")
        .select("*, orders(*, stores(name, street, neighborhood, phone), addresses(street, number, neighborhood, city))")
        .eq("id", deliveryId!)
        .single();
      if (error) throw error;
      return data;
    },
  });

  const updateStatus = useMutation({
    mutationFn: async (newStatus: string) => {
      const updates: any = { status: newStatus };
      if (newStatus === "picked_up") updates.pickup_time = new Date().toISOString();
      if (newStatus === "delivered") updates.delivery_time = new Date().toISOString();
      const { error } = await supabase.from("deliveries").update(updates).eq("id", deliveryId!);
      if (error) throw error;
      if (newStatus === "delivered") {
        await supabase.from("orders").update({ status: "delivered" }).eq("id", (delivery as any)?.order_id);
      }
      if (newStatus === "picked_up") {
        await supabase.from("orders").update({ status: "out_for_delivery" }).eq("id", (delivery as any)?.order_id);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["delivery"] });
      toast.success("Status atualizado!");
    },
  });

  const order = (delivery as any)?.orders;
  const store = order?.stores;
  const address = order?.addresses;

  const nextStatus = () => {
    const idx = statusFlow.indexOf(delivery?.status as any);
    return idx >= 0 && idx < statusFlow.length - 1 ? statusFlow[idx + 1] : null;
  };

  const openMaps = (dest: string) => {
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(dest)}`, "_blank");
  };

  if (!delivery) return <div className="min-h-screen bg-background flex items-center justify-center text-muted-foreground">Carregando...</div>;

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/entregador" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Entrega #{deliveryId?.slice(0, 8)}</h1>
      </header>

      <div className="px-4 py-4 space-y-4">
        <div className="bg-card rounded-xl p-4">
          <h2 className="font-bold text-sm mb-2">Coleta</h2>
          <p className="text-sm">{store?.name}</p>
          <p className="text-xs text-muted-foreground">{store?.street}, {store?.neighborhood}</p>
          {store?.phone && <p className="text-xs text-muted-foreground">📞 {store.phone}</p>}
          <Button variant="outline" size="sm" className="mt-2 rounded-lg gap-1"
            onClick={() => openMaps(`${store?.street}, ${store?.neighborhood}, Serra Caiada RN`)}>
            <ExternalLink className="w-3 h-3" /> Abrir no Maps
          </Button>
        </div>

        <div className="bg-card rounded-xl p-4">
          <h2 className="font-bold text-sm mb-2">Entrega</h2>
          <p className="text-sm">{address?.street}, {address?.number}</p>
          <p className="text-xs text-muted-foreground">{address?.neighborhood} - {address?.city}</p>
          <Button variant="outline" size="sm" className="mt-2 rounded-lg gap-1"
            onClick={() => openMaps(`${address?.street}, ${address?.number}, ${address?.neighborhood}, Serra Caiada RN`)}>
            <ExternalLink className="w-3 h-3" /> Abrir no Maps
          </Button>
        </div>

        <div className="bg-card rounded-xl p-4 text-center">
          <span className="text-xs text-muted-foreground">Status atual</span>
          <p className="text-lg font-bold text-primary mt-1">{statusLabels[delivery.status]}</p>
        </div>

        {nextStatus() && (
          <Button onClick={() => updateStatus.mutate(nextStatus()!)} className="w-full h-14 rounded-2xl text-base font-bold">
            {delivery.status === "accepted" ? "🏪 Coletei o pedido" : "✅ Pedido entregue"}
          </Button>
        )}
      </div>
    </div>
  );
};

export default DriverDeliveryPage;
