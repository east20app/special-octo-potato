import { ArrowLeft, MapPin, Navigation } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

const DriverOffersPage = () => {
  const queryClient = useQueryClient();

  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: offers, isLoading } = useQuery({
    queryKey: ["driver-offers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deliveries")
        .select("*, orders(id, total, delivery_fee, stores(name, street, neighborhood), addresses(street, neighborhood))")
        .eq("status", "pending")
        .is("driver_id", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    refetchInterval: 5000,
  });

  const acceptMutation = useMutation({
    mutationFn: async (deliveryId: string) => {
      const { error } = await supabase.from("deliveries")
        .update({ driver_id: session!.user.id, status: "accepted" })
        .eq("id", deliveryId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["driver-offers"] });
      toast.success("Entrega aceita!");
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/entregador" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Ofertas disponíveis</h1>
      </header>

      <div className="px-4 py-4 space-y-3">
        {isLoading ? (
          <p className="text-center text-muted-foreground py-8 text-sm">Buscando ofertas...</p>
        ) : !offers || offers.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Navigation className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Nenhuma oferta no momento</p>
            <p className="text-sm mt-1">Aguarde novas entregas</p>
          </div>
        ) : (
          offers.map((offer) => {
            const order = offer.orders as any;
            return (
              <div key={offer.id} className="bg-card rounded-xl p-4 border border-border">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-bold text-sm">{order?.stores?.name || "Loja"}</h3>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3" /> {order?.stores?.neighborhood}
                    </p>
                  </div>
                  <span className="font-bold text-primary">R$ {Number(order?.delivery_fee || 0).toFixed(2)}</span>
                </div>
                <div className="text-xs text-muted-foreground mb-3">
                  <p>📍 Entrega: {order?.addresses?.street}, {order?.addresses?.neighborhood}</p>
                  <p>💰 Valor do pedido: R$ {Number(order?.total || 0).toFixed(2)}</p>
                </div>
                <Button onClick={() => acceptMutation.mutate(offer.id)} className="w-full rounded-xl" size="sm">
                  Aceitar entrega
                </Button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default DriverOffersPage;
