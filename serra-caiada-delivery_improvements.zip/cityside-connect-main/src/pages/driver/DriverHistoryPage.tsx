import { ArrowLeft, Package } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const DriverHistoryPage = () => {
  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: deliveries, isLoading } = useQuery({
    queryKey: ["driver-history", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deliveries")
        .select("*, orders(total, delivery_fee, stores(name))")
        .eq("driver_id", session!.user.id)
        .in("status", ["delivered", "cancelled"])
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const totalEarnings = deliveries?.reduce((acc, d) => {
    if (d.status === "delivered") return acc + Number((d as any).orders?.delivery_fee || 0);
    return acc;
  }, 0) || 0;

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/entregador" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Histórico</h1>
      </header>

      <div className="px-4 py-4">
        <div className="bg-primary/10 rounded-xl p-4 mb-4 text-center">
          <p className="text-xs text-primary font-medium">Total ganho</p>
          <p className="text-2xl font-extrabold text-primary">R$ {totalEarnings.toFixed(2)}</p>
        </div>

        <div className="space-y-2">
          {isLoading ? <p className="text-center text-muted-foreground py-8 text-sm">Carregando...</p> :
            !deliveries || deliveries.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground">
                <Package className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="font-medium">Nenhuma entrega ainda</p>
              </div>
            ) : (
              deliveries.map((d) => (
                <div key={d.id} className="bg-card rounded-xl p-3 flex justify-between items-center">
                  <div>
                    <h3 className="font-semibold text-sm">{(d as any).orders?.stores?.name}</h3>
                    <p className="text-xs text-muted-foreground">{format(new Date(d.created_at), "dd/MM/yyyy HH:mm", { locale: ptBR })}</p>
                  </div>
                  <div className="text-right">
                    <span className={`text-xs font-bold ${d.status === "delivered" ? "text-success" : "text-destructive"}`}>
                      {d.status === "delivered" ? "Entregue" : "Cancelada"}
                    </span>
                    {d.status === "delivered" && (
                      <p className="text-sm font-bold text-primary">R$ {Number((d as any).orders?.delivery_fee || 0).toFixed(2)}</p>
                    )}
                  </div>
                </div>
              ))
            )}
        </div>
      </div>
    </div>
  );
};

export default DriverHistoryPage;
