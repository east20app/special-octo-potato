import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

const PrivacyPage = () => (
  <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
      <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
      <h1 className="text-lg font-bold">Política de Privacidade</h1>
    </header>
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-card rounded-2xl p-6">
        <h2 className="text-lg font-bold">Política de Privacidade - SC Delivery</h2>
        <p className="text-sm text-muted-foreground mt-3">Última atualização: Fevereiro 2026</p>
        <h3 className="font-bold mt-4 mb-2">1. Dados Coletados</h3>
        <p className="text-sm text-muted-foreground">Coletamos nome, telefone, email, endereço e dados de localização para funcionamento do serviço de delivery.</p>
        <h3 className="font-bold mt-4 mb-2">2. Uso dos Dados</h3>
        <p className="text-sm text-muted-foreground">Seus dados são usados exclusivamente para processar pedidos, entregas e melhorar a experiência na plataforma.</p>
        <h3 className="font-bold mt-4 mb-2">3. Compartilhamento</h3>
        <p className="text-sm text-muted-foreground">Compartilhamos dados de entrega com lojistas e entregadores apenas quando necessário para completar seu pedido.</p>
        <h3 className="font-bold mt-4 mb-2">4. LGPD</h3>
        <p className="text-sm text-muted-foreground">Em conformidade com a Lei Geral de Proteção de Dados (LGPD), você pode solicitar acesso, correção ou exclusão dos seus dados a qualquer momento.</p>
        <h3 className="font-bold mt-4 mb-2">5. Segurança</h3>
        <p className="text-sm text-muted-foreground">Utilizamos criptografia e boas práticas de segurança para proteger suas informações.</p>
      </div>
    </div>
    <Footer />
  </div>
);

export default PrivacyPage;
