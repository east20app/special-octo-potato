import { useState } from "react";
import { ArrowLeft, Search, ShoppingBag } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";

const SearchPage = () => {
  const [params] = useSearchParams();
  const initialQ = params.get("q") || "";
  const [query, setQuery] = useState(initialQ);

  const { data: stores, isLoading } = useQuery({
    queryKey: ["search-stores", query],
    enabled: query.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stores")
        .select("*, categories(name, icon)")
        .eq("is_active", true)
        .eq("is_approved", true)
        .or(`name.ilike.%${query}%,description.ilike.%${query}%`)
        .order("rating", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data;
    },
  });

  const { data: products } = useQuery({
    queryKey: ["search-products", query],
    enabled: query.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*, stores!inner(name, id, is_active, is_approved)")
        .eq("is_available", true)
        .eq("stores.is_active", true)
        .eq("stores.is_approved", true)
        .or(`name.ilike.%${query}%,description.ilike.%${query}%`)
        .limit(20);
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            autoFocus
            type="text"
            placeholder="Buscar lojas e produtos..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-muted text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </header>

      <div className="px-4 py-4">
        {query.length < 2 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Search className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Digite pelo menos 2 caracteres</p>
          </div>
        ) : isLoading ? (
          <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="w-full h-20 rounded-xl" />)}</div>
        ) : (
          <>
            {stores && stores.length > 0 && (
              <div className="mb-6">
                <h3 className="font-bold text-sm mb-3 text-muted-foreground uppercase tracking-wider">Lojas</h3>
                <div className="space-y-2">
                  {stores.map((s) => (
                    <Link key={s.id} to={`/loja/${s.id}`} className="flex items-center gap-3 bg-card p-3 rounded-xl">
                      <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center text-2xl shrink-0">
                        {(s.categories as any)?.icon || "🏪"}
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-semibold text-sm truncate">{s.name}</h4>
                        <p className="text-xs text-muted-foreground">{(s.categories as any)?.name} • {s.neighborhood}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
            {products && products.length > 0 && (
              <div>
                <h3 className="font-bold text-sm mb-3 text-muted-foreground uppercase tracking-wider">Produtos</h3>
                <div className="space-y-2">
                  {products.map((p) => (
                    <Link key={p.id} to={`/loja/${p.store_id}`} className="flex items-center gap-3 bg-card p-3 rounded-xl">
                      {p.image_url ? (
                        <img src={p.image_url} alt={p.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                      ) : (
                        <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center text-xl shrink-0">🍽️</div>
                      )}
                      <div className="min-w-0 flex-1">
                        <h4 className="font-semibold text-sm truncate">{p.name}</h4>
                        <p className="text-xs text-muted-foreground">{(p as any).stores?.name}</p>
                      </div>
                      <span className="text-sm font-bold text-primary shrink-0">R$ {Number(p.price).toFixed(2)}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
            {(!stores || stores.length === 0) && (!products || products.length === 0) && (
              <div className="text-center py-16 text-muted-foreground">
                <ShoppingBag className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="font-medium">Nada encontrado</p>
                <p className="text-sm mt-1">Tente outro termo</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default SearchPage;
