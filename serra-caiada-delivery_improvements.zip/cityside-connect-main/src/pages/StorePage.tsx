import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Heart, Clock, MapPin, Star, Plus, Minus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

const StorePage = () => {
  const { storeId } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [cart, setCart] = useState<Record<string, number>>({});

  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => {
      const { data } = await supabase.auth.getSession();
      return data.session;
    },
  });

  const { data: store, isLoading: loadingStore } = useQuery({
    queryKey: ["store", storeId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stores")
        .select("*, categories(name, icon)")
        .eq("id", storeId!)
        .single();
      if (error) throw error;
      return data;
    },
  });

  const { data: products, isLoading: loadingProducts } = useQuery({
    queryKey: ["products", storeId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .eq("store_id", storeId!)
        .eq("is_available", true)
        .order("sort_order")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  const productsByCategory = products?.reduce((acc, p) => {
    const cat = p.category_name || "Geral";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(p);
    return acc;
  }, {} as Record<string, typeof products>);

  const addToCartMutation = useMutation({
    mutationFn: async (productId: string) => {
      if (!session?.user?.id) {
        throw new Error("Faça login para adicionar ao carrinho");
      }
      const product = products?.find((p) => p.id === productId);
      if (!product) throw new Error("Produto não encontrado");

      // Find or create cart for this store
      const { data: existingCart, error: cartErr } = await supabase
        .from("carts")
        .select("id")
        .eq("user_id", session.user.id)
        .eq("store_id", storeId!)
        .maybeSingle();
      if (cartErr) throw cartErr;

      const cartId = existingCart?.id
        ? existingCart.id
        : (await supabase
            .from("carts")
            .insert({ user_id: session.user.id, store_id: storeId })
            .select("id")
            .single()).data?.id;

      if (!cartId) throw new Error("Não foi possível criar o carrinho");

      // Upsert cart item
      const { data: existingItem, error: itemErr } = await supabase
        .from("cart_items")
        .select("id, quantity")
        .eq("cart_id", cartId)
        .eq("product_id", productId)
        .maybeSingle();
      if (itemErr) throw itemErr;

      if (existingItem?.id) {
        const { error } = await supabase
          .from("cart_items")
          .update({ quantity: (existingItem.quantity || 1) + 1 })
          .eq("id", existingItem.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("cart_items").insert({
          cart_id: cartId,
          product_id: productId,
          quantity: 1,
          unit_price: product.price,
        });
        if (error) throw error;
      }
    },
    onSuccess: async () => {
      toast.success("Item adicionado!");
      await queryClient.invalidateQueries({ queryKey: ["user-cart"] });
    },
    onError: (e: any) => {
      toast.error(e.message || "Erro ao adicionar");
      if ((e?.message || "").toLowerCase().includes("login")) {
        navigate("/auth");
      }
    },
  });

  const addToCart = (productId: string) => {
    // Keep local UI feedback instant
    setCart((prev) => ({ ...prev, [productId]: (prev[productId] || 0) + 1 }));
    addToCartMutation.mutate(productId);
  };

  const removeFromCartMutation = useMutation({
    mutationFn: async (productId: string) => {
      if (!session?.user?.id) return;
      const { data: cartRow, error: cartErr } = await supabase
        .from("carts")
        .select("id")
        .eq("user_id", session.user.id)
        .eq("store_id", storeId!)
        .maybeSingle();
      if (cartErr) throw cartErr;
      if (!cartRow?.id) return;

      const { data: item, error: itemErr } = await supabase
        .from("cart_items")
        .select("id, quantity")
        .eq("cart_id", cartRow.id)
        .eq("product_id", productId)
        .maybeSingle();
      if (itemErr) throw itemErr;
      if (!item?.id) return;

      const nextQty = (item.quantity || 1) - 1;
      if (nextQty <= 0) {
        const { error } = await supabase.from("cart_items").delete().eq("id", item.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("cart_items").update({ quantity: nextQty }).eq("id", item.id);
        if (error) throw error;
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["user-cart"] }),
  });

  const removeFromCart = (productId: string) => {
    setCart((prev) => {
      const qty = (prev[productId] || 0) - 1;
      if (qty <= 0) {
        const { [productId]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [productId]: qty };
    });

    removeFromCartMutation.mutate(productId);
  };

  const totalItems = Object.values(cart).reduce((a, b) => a + b, 0);
  const totalPrice = products
    ? Object.entries(cart).reduce((acc, [id, qty]) => {
        const p = products.find((p) => p.id === id);
        return acc + (p ? Number(p.price) * qty : 0);
      }, 0)
    : 0;

  if (loadingStore) {
    return (
      <div className="min-h-screen bg-background">
        <Skeleton className="w-full h-56" />
        <div className="p-4 space-y-3">
          <Skeleton className="w-3/4 h-7" />
          <Skeleton className="w-1/2 h-5" />
          <Skeleton className="w-full h-20" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Banner */}
      <div className="relative h-56 bg-muted">
        {store?.banner_url ? (
          <img src={store.banner_url} alt={store.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/30 to-secondary/30">
            <span className="text-7xl">{(store?.categories as any)?.icon || "🏪"}</span>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 to-transparent" />
        <div className="absolute top-4 left-4 right-4 flex justify-between">
          <Link to="/" className="w-10 h-10 rounded-full bg-card/80 backdrop-blur flex items-center justify-center">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <button className="w-10 h-10 rounded-full bg-card/80 backdrop-blur flex items-center justify-center">
            <Heart className="w-5 h-5" />
          </button>
        </div>
        <div className="absolute bottom-4 left-4 right-4 text-primary-foreground">
          <h1 className="text-2xl font-extrabold drop-shadow">{store?.name}</h1>
          <p className="text-sm opacity-90">{(store?.categories as any)?.name}</p>
        </div>
      </div>

      {/* Info */}
      <div className="px-4 py-3 flex items-center gap-4 text-sm border-b border-border bg-card">
        {Number(store?.rating) > 0 && (
          <span className="flex items-center gap-1 font-bold text-warning">
            <Star className="w-4 h-4 fill-current" /> {Number(store?.rating).toFixed(1)}
          </span>
        )}
        <span className="flex items-center gap-1 text-muted-foreground">
          <Clock className="w-4 h-4" /> {store?.avg_prep_time_min} min
        </span>
        <span className="flex items-center gap-1 text-muted-foreground">
          <MapPin className="w-4 h-4" /> {store?.neighborhood}
        </span>
        <span className="ml-auto font-semibold text-primary">
          {Number(store?.delivery_fee) === 0
            ? "Frete grátis"
            : `R$ ${Number(store?.delivery_fee).toFixed(2)}`}
        </span>
      </div>

      {store?.description && (
        <p className="px-4 py-3 text-sm text-muted-foreground bg-card border-b border-border">
          {store.description}
        </p>
      )}

      {/* Products */}
      <div className="px-4 py-4">
        {loadingProducts ? (
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex gap-3">
                <Skeleton className="w-full h-24 rounded-xl" />
              </div>
            ))}
          </div>
        ) : (
          Object.entries(productsByCategory || {}).map(([category, items]) => (
            <div key={category} className="mb-6">
              <h3 className="text-base font-bold mb-3 text-foreground">{category}</h3>
              <div className="space-y-3">
                {items.map((product) => (
                  <div
                    key={product.id}
                    className="bg-card rounded-2xl p-3 flex gap-3 shadow-sm"
                  >
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-sm truncate">{product.name}</h4>
                      {product.description && (
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                          {product.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-sm font-bold text-primary">
                          R$ {Number(product.price).toFixed(2)}
                        </span>
                        {product.original_price && Number(product.original_price) > Number(product.price) && (
                          <span className="text-xs text-muted-foreground line-through">
                            R$ {Number(product.original_price).toFixed(2)}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                      {product.image_url ? (
                        <img
                          src={product.image_url}
                          alt={product.name}
                          className="w-20 h-20 rounded-xl object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <div className="w-20 h-20 rounded-xl bg-muted flex items-center justify-center text-3xl">
                          🍽️
                        </div>
                      )}
                      {cart[product.id] ? (
                        <div className="flex items-center gap-2 bg-primary rounded-full px-1">
                          <button
                            onClick={() => removeFromCart(product.id)}
                            className="w-7 h-7 flex items-center justify-center text-primary-foreground"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="text-sm font-bold text-primary-foreground min-w-[16px] text-center">
                            {cart[product.id]}
                          </span>
                          <button
                            onClick={() => addToCart(product.id)}
                            className="w-7 h-7 flex items-center justify-center text-primary-foreground"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => addToCart(product.id)}
                          className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-md"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Cart Footer */}
      {totalItems > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-card border-t border-border animate-slide-up z-40">
          <Link to="/carrinho">
            <Button className="w-full h-14 rounded-2xl text-base font-bold shadow-lg gap-3">
              <span className="bg-primary-foreground/20 px-2.5 py-1 rounded-lg text-sm">
                {totalItems}
              </span>
              <span className="flex-1">Ver carrinho</span>
              <span>R$ {totalPrice.toFixed(2)}</span>
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default StorePage;
