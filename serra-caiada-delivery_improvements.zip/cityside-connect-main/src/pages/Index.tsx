import { useState, useEffect } from "react";
import { Search, MapPin, ShoppingBag, User, ChevronDown, Utensils, ShoppingCart, Package, Navigation, Star, Clock, Filter, ArrowRight, Smartphone, ChevronRight, Truck, Store, HelpCircle } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const Index = () => {
  const navigate = useNavigate();

  // Location is recommended, but we don't hard-redirect anymore.
  // Hard redirects were making PWA install / first access feel "buggy".
  const hasGps = !!(localStorage.getItem("user_lat") && localStorage.getItem("user_lng"));
  const hasManual = !!localStorage.getItem("user_neighborhood");
  const needsLocation = !(hasGps || hasManual);

  const locationMode = localStorage.getItem("location_mode");
  const street = localStorage.getItem("user_street");
  const number = localStorage.getItem("user_number");
  const neighborhood = localStorage.getItem("user_neighborhood");
  const selectedAddress = neighborhood
    ? `${street ? `${street}${number ? `, ${number}` : ""} - ` : ""}${neighborhood}`
    : (needsLocation ? "Definir endereço" : "Serra Caiada, RN");

  const [searchQuery, setSearchQuery] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [filterFreeDelivery, setFilterFreeDelivery] = useState(false);
  const [sortBy, setSortBy] = useState<"rating" | "avg_prep_time_min" | "delivery_fee">("rating");

  const { data: categories, isLoading: loadingCategories, error: catError } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories").select("*").eq("is_active", true).order("sort_order");
      if (error) {
        if (error.message.includes("does not exist")) return [];
        throw error;
      }
      return data;
    },
  });

  const { data: stores, isLoading: loadingStores, error: storeError } = useQuery({
    queryKey: ["stores"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stores").select("*, categories(name, icon)")
        .eq("is_active", true).eq("is_approved", true)
        .eq("city", "Serra Caiada")
        .order("rating", { ascending: false });
      if (error) {
        if (error.message.includes("does not exist")) return [];
        throw error;
      }
      return data;
    },
  });

  const { data: serviceArea } = useQuery({
    queryKey: ["service-area"],
    queryFn: async () => {
      const { data } = await supabase.from("city_service_areas").select("*").eq("is_active", true).maybeSingle();
      return data;
    },
  });

  let filteredStores = stores?.filter(
    (s) =>
      (!searchQuery ||
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.description?.toLowerCase().includes(searchQuery.toLowerCase())) &&
      (!filterFreeDelivery || Number(s.delivery_fee) === 0) &&
      (!filterOpen || s.is_open)
  );
  if (filteredStores) {
    filteredStores = [...filteredStores].sort((a, b) => {
      if (sortBy === "rating") return Number(b.rating || 0) - Number(a.rating || 0);
      if (sortBy === "avg_prep_time_min") return Number(a.avg_prep_time_min || 0) - Number(b.avg_prep_time_min || 0);
      return Number(a.delivery_fee || 0) - Number(b.delivery_fee || 0);
    });
  }

  const freeDeliveryStores = stores?.filter((s) => Number(s.delivery_fee) === 0 && s.is_open).slice(0, 6);
  const topRatedStores = stores?.filter((s) => Number(s.rating) > 0).sort((a, b) => Number(b.rating || 0) - Number(a.rating || 0)).slice(0, 6);
  const fastestStores = stores?.filter((s) => s.is_open).sort((a, b) => Number(a.avg_prep_time_min || 99) - Number(b.avg_prep_time_min || 99)).slice(0, 6);

  return (
    <div className="min-h-screen bg-background">
      {/* ===== HEADER FIXO ===== */}
      <header className="sticky top-0 z-40 bg-primary text-primary-foreground shadow-lg">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-extrabold tracking-tight">🛵 SC Delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <Link to="/carrinho" className="p-2 rounded-full bg-primary-foreground/20 relative">
                <ShoppingBag className="w-5 h-5" />
              </Link>
              <Link to="/perfil" className="p-2 rounded-full bg-primary-foreground/20">
                <User className="w-5 h-5" />
              </Link>
            </div>
          </div>

          <div className="flex items-center gap-2 mb-3">
            <button onClick={() => navigate("/localizacao")} className="flex items-center gap-1.5 text-sm font-medium bg-primary-foreground/10 rounded-xl px-3 py-1.5 hover:bg-primary-foreground/20 transition-colors">
              <MapPin className="w-4 h-4" />
              <span className="max-w-[180px] truncate">Entregar em: {selectedAddress}</span>
              <ChevronDown className="w-3 h-3" />
            </button>
          </div>

          {needsLocation && (
            <div className="mt-2 rounded-xl bg-primary-foreground/10 px-3 py-2 text-xs leading-relaxed">
              <span className="font-semibold">Defina seu endereço</span> para ver lojas mais próximas e calcular entrega.
              <button
                onClick={() => navigate("/localizacao")}
                className="ml-2 underline font-semibold"
              >
                Configurar agora
              </button>
            </div>
          )}

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Buscar lojas e produtos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => navigate("/buscar")}
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-card text-card-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>
      </header>

      {/* ===== CARDS PRINCIPAIS ===== */}
      <section className="max-w-6xl mx-auto px-4 py-5">
        <div className="grid grid-cols-3 gap-3">
          <button onClick={() => navigate("/explorar/lanches")} className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl p-4 text-center shadow-md hover:shadow-lg transition-shadow">
            <Utensils className="w-8 h-8 mx-auto mb-2" />
            <span className="text-sm font-bold">Pedir comida</span>
          </button>
          <button onClick={() => navigate("/explorar/mercado")} className="bg-gradient-to-br from-secondary to-secondary/80 text-secondary-foreground rounded-2xl p-4 text-center shadow-md hover:shadow-lg transition-shadow">
            <ShoppingCart className="w-8 h-8 mx-auto mb-2" />
            <span className="text-sm font-bold">Comprar em lojas</span>
          </button>
          <Link to="/pedidos" className="bg-gradient-to-br from-success to-success/80 text-success-foreground rounded-2xl p-4 text-center shadow-md hover:shadow-lg transition-shadow">
            <Package className="w-8 h-8 mx-auto mb-2" />
            <span className="text-sm font-bold">Acompanhar pedido</span>
          </Link>
        </div>
      </section>

      {/* ===== PROMO BANNER ===== */}
      <section className="max-w-6xl mx-auto px-4 mb-5">
        <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-5 text-primary-foreground">
          <p className="text-xs font-semibold uppercase tracking-wider opacity-80">Primeira compra</p>
          <h3 className="text-xl font-extrabold mt-1">Frete GRÁTIS 🎉</h3>
          <p className="text-sm mt-1 opacity-90">Use o cupom <span className="font-bold bg-primary-foreground/20 px-2 py-0.5 rounded">BEMVINDO</span></p>
        </div>
      </section>

      {/* ===== CATEGORIAS ===== */}
      <section className="max-w-6xl mx-auto px-4 py-3">
        <h2 className="text-lg font-bold mb-3">Categorias</h2>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
          {loadingCategories
            ? Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="flex flex-col items-center gap-1.5 min-w-[72px]">
                  <Skeleton className="w-14 h-14 rounded-2xl" />
                  <Skeleton className="w-12 h-3" />
                </div>
              ))
            : categories?.map((cat) => (
                <Link key={cat.id} to={`/explorar/${cat.slug}`} className="flex flex-col items-center gap-1.5 min-w-[72px] group">
                  <div className="w-14 h-14 rounded-2xl bg-accent flex items-center justify-center text-2xl group-hover:bg-primary group-hover:text-primary-foreground transition-colors shadow-sm">
                    {cat.icon}
                  </div>
                  <span className="text-xs font-medium text-foreground text-center leading-tight">{cat.name}</span>
                </Link>
              ))}
        </div>
      </section>

      {/* ===== DESTAQUES: ENTREGA GRÁTIS ===== */}
      {freeDeliveryStores && freeDeliveryStores.length > 0 && (
        <section className="max-w-6xl mx-auto px-4 py-3">
          <h2 className="text-lg font-bold mb-3">🟢 Entrega grátis</h2>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
            {freeDeliveryStores.map((store) => (
              <Link key={store.id} to={`/loja/${store.id}`} className="min-w-[200px] bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow shrink-0">
                <div className="h-24 bg-muted">
                  {store.banner_url ? <img src={store.banner_url} alt={store.name} className="w-full h-full object-cover" loading="lazy" />
                    : <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20"><span className="text-4xl">{(store.categories as any)?.icon || "🏪"}</span></div>}
                </div>
                <div className="p-2.5">
                  <h4 className="font-bold text-sm truncate">{store.name}</h4>
                  <p className="text-[10px] text-success font-bold">Frete grátis • {store.avg_prep_time_min} min</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ===== DESTAQUES: MAIS BEM AVALIADOS ===== */}
      {topRatedStores && topRatedStores.length > 0 && (
        <section className="max-w-6xl mx-auto px-4 py-3">
          <h2 className="text-lg font-bold mb-3">⭐ Mais bem avaliados</h2>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
            {topRatedStores.map((store) => (
              <Link key={store.id} to={`/loja/${store.id}`} className="min-w-[200px] bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow shrink-0">
                <div className="h-24 bg-muted">
                  {store.banner_url ? <img src={store.banner_url} alt={store.name} className="w-full h-full object-cover" loading="lazy" />
                    : <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20"><span className="text-4xl">{(store.categories as any)?.icon || "🏪"}</span></div>}
                </div>
                <div className="p-2.5">
                  <h4 className="font-bold text-sm truncate">{store.name}</h4>
                  <p className="text-[10px] text-warning font-bold">⭐ {Number(store.rating).toFixed(1)} • {store.avg_prep_time_min} min</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ===== DESTAQUES: MAIS RÁPIDOS ===== */}
      {fastestStores && fastestStores.length > 0 && (
        <section className="max-w-6xl mx-auto px-4 py-3">
          <h2 className="text-lg font-bold mb-3">⚡ Mais rápidos</h2>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
            {fastestStores.map((store) => (
              <Link key={store.id} to={`/loja/${store.id}`} className="min-w-[200px] bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow shrink-0">
                <div className="h-24 bg-muted">
                  {store.banner_url ? <img src={store.banner_url} alt={store.name} className="w-full h-full object-cover" loading="lazy" />
                    : <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20"><span className="text-4xl">{(store.categories as any)?.icon || "🏪"}</span></div>}
                </div>
                <div className="p-2.5">
                  <h4 className="font-bold text-sm truncate">{store.name}</h4>
                  <p className="text-[10px] text-primary font-bold">🕐 {store.avg_prep_time_min} min</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ===== LOJAS PERTO + FILTROS ===== */}
      <section className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold">Lojas perto de você</h2>
        </div>

        <div className="flex gap-2 overflow-x-auto scrollbar-hide mb-4 pb-1">
          <button onClick={() => setFilterOpen(!filterOpen)}
            className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap flex items-center gap-1 ${filterOpen ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            Aberto agora
          </button>
          <button onClick={() => setFilterFreeDelivery(!filterFreeDelivery)}
            className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${filterFreeDelivery ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            Entrega grátis
          </button>
          <button onClick={() => setSortBy("rating")}
            className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${sortBy === "rating" ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            Melhor nota
          </button>
          <button onClick={() => setSortBy("avg_prep_time_min")}
            className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${sortBy === "avg_prep_time_min" ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            Menor tempo
          </button>
          <button onClick={() => setSortBy("delivery_fee")}
            className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${sortBy === "delivery_fee" ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            Menor frete
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {loadingStores
            ? Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-card rounded-2xl overflow-hidden shadow-sm">
                  <Skeleton className="w-full h-36" />
                  <div className="p-3"><Skeleton className="w-3/4 h-5 mb-2" /><Skeleton className="w-1/2 h-4" /></div>
                </div>
              ))
            : filteredStores?.length === 0 ? (
                <div className="col-span-full text-center py-10 text-muted-foreground">
                  <ShoppingBag className="w-12 h-12 mx-auto mb-3 opacity-40" />
                  <p className="font-medium">Nenhuma loja encontrada</p>
                  <p className="text-sm">Tente buscar por outro termo</p>
                </div>
              ) : (
                filteredStores?.map((store) => (
                  <Link key={store.id} to={`/loja/${store.id}`}
                    className="bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                    <div className="relative h-36 bg-muted">
                      {store.banner_url ? (
                        <img src={store.banner_url} alt={store.name} className="w-full h-full object-cover" loading="lazy" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20">
                          <span className="text-5xl">{(store.categories as any)?.icon || "🏪"}</span>
                        </div>
                      )}
                      {store.is_open ? (
                        <span className="absolute top-3 left-3 bg-success text-success-foreground text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">Aberto</span>
                      ) : (
                        <span className="absolute top-3 left-3 bg-muted text-muted-foreground text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">Fechado</span>
                      )}
                    </div>
                    <div className="p-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-bold text-base">{store.name}</h3>
                          <p className="text-xs text-muted-foreground mt-0.5">{(store.categories as any)?.name} • {store.neighborhood}</p>
                        </div>
                        {Number(store.rating) > 0 && (
                          <span className="flex items-center gap-1 text-xs font-bold bg-warning/10 text-warning px-2 py-1 rounded-lg">⭐ {Number(store.rating).toFixed(1)}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                        <span>🕐 {store.avg_prep_time_min} min</span>
                        <span>•</span>
                        <span>{Number(store.delivery_fee) === 0 ? "🟢 Frete grátis" : `🛵 R$ ${Number(store.delivery_fee).toFixed(2)}`}</span>
                        {store.min_order_value && Number(store.min_order_value) > 0 && (
                          <><span>•</span><span>Mín. R$ {Number(store.min_order_value).toFixed(2)}</span></>
                        )}
                      </div>
                    </div>
                  </Link>
                ))
              )}
        </div>
      </section>

      {/* ===== COMO FUNCIONA ===== */}
      <section className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-lg font-bold mb-5 text-center">Como funciona</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { emoji: "🔍", title: "1. Escolha", desc: "Encontre lojas e produtos perto de você em Serra Caiada" },
            { emoji: "💳", title: "2. Pague", desc: "PIX, cartão ou dinheiro na entrega — você escolhe" },
            { emoji: "🛵", title: "3. Receba", desc: "Acompanhe em tempo real até seu pedido chegar" },
          ].map((step) => (
            <div key={step.title} className="bg-card rounded-2xl p-6 text-center shadow-sm">
              <span className="text-4xl">{step.emoji}</span>
              <h3 className="font-bold text-base mt-3">{step.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ===== ÁREA PROFISSIONAL ===== */}
      <section className="max-w-6xl mx-auto px-4 py-6">
        <h2 className="text-lg font-bold mb-4">Área Profissional</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Link to="/seja-entregador" className="bg-card rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow group">
            <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center shrink-0">
              <Truck className="w-6 h-6 text-warning" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-sm">Seja um Entregador</h3>
              <p className="text-xs text-muted-foreground">Ganhe dinheiro fazendo entregas</p>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
          </Link>
          <Link to="/seja-parceiro" className="bg-card rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow group">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Store className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-sm">Seja um Parceiro / Lojista</h3>
              <p className="text-xs text-muted-foreground">Venda mais com delivery</p>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
          </Link>
          <Link to="/ajuda" className="bg-card rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow group">
            <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center shrink-0">
              <HelpCircle className="w-6 h-6 text-success" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-sm">Central de Ajuda</h3>
              <p className="text-xs text-muted-foreground">Dúvidas e suporte</p>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
          </Link>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <Footer neighborhoods={serviceArea?.neighborhoods || []} />

      {/* ===== BOTTOM NAV (mobile) ===== */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 py-2 flex justify-around items-center z-40 md:hidden safe-area-bottom">
        <Link to="/" className="flex flex-col items-center gap-0.5 text-primary">
          <Search className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Início</span>
        </Link>
        <Link to="/buscar" className="flex flex-col items-center gap-0.5 text-muted-foreground">
          <Search className="w-5 h-5" />
          <span className="text-[10px] font-medium">Buscar</span>
        </Link>
        <Link to="/pedidos" className="flex flex-col items-center gap-0.5 text-muted-foreground">
          <Package className="w-5 h-5" />
          <span className="text-[10px] font-medium">Pedidos</span>
        </Link>
        <Link to="/perfil" className="flex flex-col items-center gap-0.5 text-muted-foreground">
          <User className="w-5 h-5" />
          <span className="text-[10px] font-medium">Perfil</span>
        </Link>
      </nav>

      <div className="h-16 md:hidden" />
    </div>
  );
};

export default Index;
