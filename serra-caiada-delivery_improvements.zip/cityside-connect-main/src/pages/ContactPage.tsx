import { ArrowLeft, Phone, Mail, MessageCircle, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

const ContactPage = () => (
  <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
      <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
      <h1 className="text-lg font-bold">Contato</h1>
    </header>
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-4">
      <div className="bg-card rounded-2xl p-6 text-center">
        <MessageCircle className="w-12 h-12 mx-auto mb-3 text-primary" />
        <h2 className="text-lg font-bold">Fale conosco</h2>
        <p className="text-sm text-muted-foreground mt-1">Estamos prontos para ajudar!</p>
      </div>

      {[
        { icon: Phone, label: "WhatsApp", value: "(84) 99999-9999", href: "https://wa.me/5584999999999", color: "bg-success/10 text-success" },
        { icon: Mail, label: "Email", value: "contato@scdelivery.com.br", href: "mailto:contato@scdelivery.com.br", color: "bg-primary/10 text-primary" },
        { icon: MapPin, label: "Endereço", value: "Serra Caiada - RN", href: "#", color: "bg-secondary/10 text-secondary" },
      ].map((c) => (
        <a key={c.label} href={c.href} target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-4 bg-card p-4 rounded-xl hover:bg-accent transition-colors">
          <div className={`w-10 h-10 rounded-full ${c.color} flex items-center justify-center`}><c.icon className="w-5 h-5" /></div>
          <div>
            <h3 className="font-bold text-sm">{c.label}</h3>
            <p className="text-xs text-muted-foreground">{c.value}</p>
          </div>
        </a>
      ))}
    </div>
    <Footer />
  </div>
);

export default ContactPage;
