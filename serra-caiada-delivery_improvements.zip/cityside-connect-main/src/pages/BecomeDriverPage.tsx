import { useState } from "react";
import { ArrowLeft, Truck, DollarSign, Clock, CheckCircle, Loader2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import Footer from "@/components/Footer";
import { useAuth } from "@/hooks/useAuth";

const isMissingDriverTable = (message?: string) => {
  if (!message) return false;
  const m = message.toLowerCase();
  return m.includes("does not exist") || m.includes("schema cache") || m.includes("could not find the table") || m.includes("driver_applications");
};

const BecomeDriverPage = () => {
  const navigate = useNavigate();
  const { user, isLoading: authLoading } = useAuth();
  const [form, setForm] = useState({ full_name: "", phone: "", document: "", vehicle: "moto" });
  const [submitting, setSubmitting] = useState(false);

  // Check existing application
  const { data: existingApp, isLoading: appLoading, error: appError } = useQuery({
    queryKey: ["driver-application", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("driver_applications")
        .select("*")
        .eq("user_id", user!.id)
        .maybeSingle();
      if (error && !isMissingDriverTable(error.message)) throw error;
      return data;
    },
  });

  const handleSubmit = async () => {
    if (!form.full_name || !form.phone) {
      toast.error("Preencha nome e WhatsApp");
      return;
    }
    if (!user) {
      toast.error("Faça login primeiro");
      navigate("/auth");
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from("driver_applications").insert({
        user_id: user.id,
        full_name: form.full_name,
        phone: form.phone,
        document: form.document,
        vehicle: form.vehicle,
        status: "pending",
      });
      if (error) {
        if (error.message.includes("duplicate") || error.message.includes("unique")) {
          toast.error("Você já possui uma solicitação cadastrada.");
        } else {
          throw error;
        }
      } else {
        // Also update profile name/phone
        await supabase.from("profiles").update({
          full_name: form.full_name,
          phone: form.phone,
        }).eq("user_id", user.id);
        toast.success("Cadastro enviado! Aguarde a aprovação do administrador.");
        navigate("/");
      }
    } catch (err: any) {
      toast.error(err.message || "Erro ao cadastrar");
    } finally {
      setSubmitting(false);
    }
  };

    const driverTableMissing = isMissingDriverTable((appError as any)?.message);

  const statusLabels: Record<string, { label: string; color: string }> = {
    pending: { label: "Aguardando aprovação", color: "text-warning" },
    approved: { label: "Aprovado ✅", color: "text-success" },
    rejected: { label: "Recusado", color: "text-destructive" },
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Seja um Entregador</h1>
      </header>

      {/* Hero */}
      <div className="bg-gradient-to-br from-warning to-secondary text-secondary-foreground px-6 py-10 text-center">
        <Truck className="w-16 h-16 mx-auto mb-4" />
        <h2 className="text-2xl font-extrabold">Ganhe dinheiro fazendo entregas</h2>
        <p className="text-sm opacity-90 mt-2 max-w-md mx-auto">Faça seu próprio horário e ganhe por cada entrega em Serra Caiada</p>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {driverTableMissing && (
          <div className="bg-destructive/10 border border-destructive/30 text-destructive rounded-xl p-4 mb-6">
            <p className="font-bold">Banco ainda não configurado</p>
            <p className="text-sm mt-1">
              A tabela <code>driver_applications</code> não existe no seu Supabase. Rode a migration em <code>supabase/migrations</code> e depois execute:
              <code className="ml-2">notify pgrst, 'reload schema';</code>
            </p>
          </div>
        )}

        {/* Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {[
            { icon: DollarSign, title: "Ganhos por entrega", desc: "Receba pela taxa de entrega de cada pedido", color: "text-success" },
            { icon: Clock, title: "Horário flexível", desc: "Fique online quando quiser, sem obrigação", color: "text-primary" },
            { icon: CheckCircle, title: "Pagamento rápido", desc: "Receba seus ganhos diretamente na sua conta", color: "text-warning" },
          ].map((b) => (
            <div key={b.title} className="bg-card rounded-2xl p-5 text-center shadow-sm">
              <b.icon className={`w-8 h-8 mx-auto mb-2 ${b.color}`} />
              <h3 className="font-bold text-sm">{b.title}</h3>
              <p className="text-xs text-muted-foreground mt-1">{b.desc}</p>
            </div>
          ))}
        </div>

        {/* Requirements */}
        <div className="bg-card rounded-2xl p-5 mb-8">
          <h3 className="font-bold mb-3">Requisitos</h3>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li>✅ Ser maior de 18 anos</li>
            <li>✅ Possuir veículo (moto, bicicleta ou carro)</li>
            <li>✅ Documento com foto (CNH ou RG)</li>
            <li>✅ Celular com GPS</li>
            <li>✅ Morar em Serra Caiada - RN</li>
          </ul>
        </div>

        {/* Earnings estimate */}
        <div className="bg-primary/10 border border-primary/20 rounded-2xl p-5 mb-8 text-center">
          <p className="text-xs text-primary font-bold uppercase">Ganhos estimados</p>
          <p className="text-3xl font-extrabold text-primary mt-1">R$ 50 - R$ 150</p>
          <p className="text-xs text-muted-foreground mt-1">por dia, dependendo da demanda</p>
        </div>

        {/* Existing application status */}
        {existingApp && (
          <div className="bg-card rounded-2xl p-6 mb-8 border border-border">
            <h3 className="font-bold mb-2">Sua solicitação</h3>
            <p className={`font-bold ${statusLabels[existingApp.status]?.color}`}>
              {statusLabels[existingApp.status]?.label}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Enviada em {new Date(existingApp.created_at).toLocaleDateString("pt-BR")}
            </p>
            {existingApp.status === "rejected" && existingApp.rejection_reason && (
              <p className="text-xs text-destructive mt-2">Motivo: {existingApp.rejection_reason}</p>
            )}
          </div>
        )}

        {/* Form - only show if no existing application */}
        {!existingApp && (
          <div className="bg-card rounded-2xl p-6">
            <h3 className="font-bold mb-4">Cadastre-se</h3>
            <div className="space-y-3">
              <Input placeholder="Nome completo" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
              <Input placeholder="WhatsApp (84) 99999-9999" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              <Input placeholder="CPF ou CNH" value={form.document} onChange={(e) => setForm({ ...form, document: e.target.value })} />
              <Select value={form.vehicle} onValueChange={(v) => setForm({ ...form, vehicle: v })}>
                <SelectTrigger><SelectValue placeholder="Tipo de veículo" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="moto">🏍️ Moto</SelectItem>
                  <SelectItem value="bicicleta">🚲 Bicicleta</SelectItem>
                  <SelectItem value="carro">🚗 Carro</SelectItem>
                </SelectContent>
              </Select>

              {!user && !authLoading ? (
                <Link to="/auth">
                  <Button className="w-full rounded-xl h-12">Fazer login para se cadastrar</Button>
                </Link>
              ) : (
                <Button onClick={handleSubmit} disabled={submitting} className="w-full rounded-xl h-12">
                  {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Enviar cadastro"}
                </Button>
              )}
              <p className="text-xs text-muted-foreground text-center">Após o envio, o admin vai analisar e aprovar seu cadastro.</p>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default BecomeDriverPage;
