import { ArrowLeft, Shield, Lock, Eye, AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

const SecurityPage = () => (
  <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
      <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
      <h1 className="text-lg font-bold">Segurança</h1>
    </header>
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-4">
      {[
        { icon: Shield, title: "Dados protegidos", desc: "Suas informações pessoais são criptografadas e armazenadas com segurança.", color: "bg-primary/10 text-primary" },
        { icon: Lock, title: "Pagamentos seguros", desc: "PIX e cartão processados com tecnologia de ponta. Não armazenamos dados de cartão.", color: "bg-success/10 text-success" },
        { icon: Eye, title: "Privacidade", desc: "Respeitamos a LGPD. Você tem controle total sobre seus dados pessoais.", color: "bg-secondary/10 text-secondary" },
        { icon: AlertTriangle, title: "Prevenção a fraudes", desc: "Sistema de monitoramento contra pedidos fraudulentos e contas suspeitas.", color: "bg-warning/10 text-warning" },
      ].map((item) => (
        <div key={item.title} className="bg-card rounded-2xl p-5 flex gap-4">
          <div className={`w-12 h-12 rounded-xl ${item.color} flex items-center justify-center shrink-0`}>
            <item.icon className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-sm">{item.title}</h3>
            <p className="text-sm text-muted-foreground mt-0.5">{item.desc}</p>
          </div>
        </div>
      ))}
    </div>
    <Footer />
  </div>
);

export default SecurityPage;
