import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, LogOut, MapPin, Heart, ShoppingBag, Settings, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { User } from "@supabase/supabase-js";

const ProfilePage = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<{ full_name: string; phone: string | null } | null>(null);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        supabase
          .from("profiles")
          .select("full_name, phone")
          .eq("user_id", session.user.id)
          .single()
          .then(({ data }) => setProfile(data));
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 text-center">
        <div className="w-20 h-20 rounded-full bg-accent flex items-center justify-center text-4xl mb-4">
          👤
        </div>
        <h2 className="text-xl font-bold">Entre na sua conta</h2>
        <p className="text-sm text-muted-foreground mt-1 mb-6">
          Faça login para ver seus pedidos, favoritos e mais
        </p>
        <Link to="/auth">
          <Button className="rounded-xl px-10 h-12 text-base">Entrar / Cadastrar</Button>
        </Link>
        <Link to="/" className="mt-4 text-sm text-muted-foreground">
          ← Voltar para início
        </Link>
      </div>
    );
  }

  const menuItems = [
    { icon: ShoppingBag, label: "Meus pedidos", to: "/pedidos" },
    { icon: Heart, label: "Favoritos", to: "/favoritos" },
    { icon: MapPin, label: "Endereços", to: "/enderecos" },
    { icon: Settings, label: "Configurações", to: "/configuracoes" },
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-primary text-primary-foreground px-4 pt-10 pb-6 rounded-b-3xl">
        <div className="flex items-center gap-3 mb-4">
          <Link to="/" className="p-2 -ml-2">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-lg font-bold">Meu perfil</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-primary-foreground/20 flex items-center justify-center text-3xl">
            👤
          </div>
          <div>
            <h2 className="text-xl font-bold">{profile?.full_name || "Usuário"}</h2>
            <p className="text-sm opacity-80">{user.email}</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-2">
        {menuItems.map((item) => (
          <Link
            key={item.label}
            to={item.to}
            className="flex items-center gap-4 bg-card rounded-2xl p-4 shadow-sm"
          >
            <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center">
              <item.icon className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="flex-1 font-medium">{item.label}</span>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </Link>
        ))}

        <button
          onClick={handleLogout}
          className="flex items-center gap-4 bg-card rounded-2xl p-4 shadow-sm w-full mt-4"
        >
          <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
            <LogOut className="w-5 h-5 text-destructive" />
          </div>
          <span className="flex-1 font-medium text-destructive text-left">Sair da conta</span>
        </button>
      </div>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 py-2 flex justify-around items-center z-40">
        <Link to="/" className="flex flex-col items-center gap-0.5 text-muted-foreground">
          <ShoppingBag className="w-5 h-5" />
          <span className="text-[10px] font-medium">Início</span>
        </Link>
        <Link to="/carrinho" className="flex flex-col items-center gap-0.5 text-muted-foreground">
          <ShoppingBag className="w-5 h-5" />
          <span className="text-[10px] font-medium">Carrinho</span>
        </Link>
        <Link to="/perfil" className="flex flex-col items-center gap-0.5 text-primary">
          <Settings className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Perfil</span>
        </Link>
      </nav>
    </div>
  );
};

export default ProfilePage;
