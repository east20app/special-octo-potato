import { ArrowLeft, Package } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const statusLabels: Record<string, { label: string; color: string }> = {
  pending: { label: "Pendente", color: "bg-warning/10 text-warning" },
  received: { label: "Recebido", color: "bg-primary/10 text-primary" },
  preparing: { label: "Preparando", color: "bg-secondary/10 text-secondary" },
  ready: { label: "Pronto", color: "bg-success/10 text-success" },
  waiting_driver: { label: "Aguardando entregador", color: "bg-warning/10 text-warning" },
  out_for_delivery: { label: "Saiu para entrega", color: "bg-primary/10 text-primary" },
  delivered: { label: "Entregue", color: "bg-success/10 text-success" },
  cancelled: { label: "Cancelado", color: "bg-destructive/10 text-destructive" },
};

const OrdersHistoryPage = () => {
  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: orders, isLoading } = useQuery({
    queryKey: ["my-orders", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("*, stores(name, logo_url)")
        .eq("user_id", session!.user.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/perfil" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Meus pedidos</h1>
      </header>

      <div className="px-4 py-4 space-y-3">
        {isLoading ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="w-full h-20 rounded-xl" />)
        ) : !orders || orders.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Package className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Nenhum pedido ainda</p>
          </div>
        ) : (
          orders.map((order) => {
            const st = statusLabels[order.status] || { label: order.status, color: "" };
            return (
              <Link key={order.id} to={`/pedido/${order.id}`}
                className="bg-card rounded-xl p-4 block shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-bold text-sm">{(order as any).stores?.name || "Loja"}</h3>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${st.color}`}>{st.label}</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{format(new Date(order.created_at), "dd MMM yyyy, HH:mm", { locale: ptBR })}</span>
                  <span className="font-bold text-foreground">R$ {Number(order.total).toFixed(2)}</span>
                </div>
              </Link>
            );
          })
        )}
      </div>
    </div>
  );
};

export default OrdersHistoryPage;
