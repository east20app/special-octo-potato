import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Star, Clock, Filter } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";

const ExploreCategoryPage = () => {
  const { categorySlug } = useParams();
  const [sortBy, setSortBy] = useState<"rating" | "delivery_fee" | "avg_prep_time_min">("rating");
  const [onlyOpen, setOnlyOpen] = useState(false);

  const { data: category } = useQuery({
    queryKey: ["category", categorySlug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .eq("slug", categorySlug!)
        .single();
      if (error) throw error;
      return data;
    },
  });

  const { data: stores, isLoading } = useQuery({
    queryKey: ["stores-by-category", category?.id, sortBy, onlyOpen],
    enabled: !!category?.id,
    queryFn: async () => {
      let q = supabase
        .from("stores")
        .select("*, categories(name, icon)")
        .eq("category_id", category!.id)
        .eq("is_active", true)
        .eq("is_approved", true);
      if (onlyOpen) q = q.eq("is_open", true);
      q = q.order(sortBy, { ascending: sortBy !== "rating" });
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold flex items-center gap-2">
          {category?.icon && <span className="text-xl">{category.icon}</span>}
          {category?.name || "Categoria"}
        </h1>
      </header>

      {/* Filters */}
      <div className="px-4 py-3 flex gap-2 overflow-x-auto scrollbar-hide">
        <button onClick={() => setOnlyOpen(!onlyOpen)}
          className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${onlyOpen ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
          Aberto agora
        </button>
        <button onClick={() => setSortBy("rating")}
          className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${sortBy === "rating" ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
          Melhor avaliado
        </button>
        <button onClick={() => setSortBy("delivery_fee")}
          className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${sortBy === "delivery_fee" ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
          Menor frete
        </button>
        <button onClick={() => setSortBy("avg_prep_time_min")}
          className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${sortBy === "avg_prep_time_min" ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
          Mais rápido
        </button>
      </div>

      <div className="px-4 space-y-3">
        {isLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="w-full h-36 rounded-2xl" />
          ))
        ) : stores?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <p className="font-medium">Nenhuma loja encontrada</p>
            <p className="text-sm mt-1">Tente mudar os filtros</p>
          </div>
        ) : (
          stores?.map((store) => (
            <Link key={store.id} to={`/loja/${store.id}`}
              className="bg-card rounded-2xl overflow-hidden shadow-sm block hover:shadow-md transition-shadow">
              <div className="relative h-32 bg-muted">
                {store.banner_url ? (
                  <img src={store.banner_url} alt={store.name} className="w-full h-full object-cover" loading="lazy" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20">
                    <span className="text-5xl">{(store.categories as any)?.icon || "🏪"}</span>
                  </div>
                )}
                {store.is_open ? (
                  <span className="absolute top-2 left-2 bg-success text-success-foreground text-[10px] font-bold px-2 py-0.5 rounded-full">Aberto</span>
                ) : (
                  <span className="absolute top-2 left-2 bg-muted text-muted-foreground text-[10px] font-bold px-2 py-0.5 rounded-full">Fechado</span>
                )}
              </div>
              <div className="p-3">
                <h3 className="font-bold">{store.name}</h3>
                <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                  {Number(store.rating) > 0 && <span className="flex items-center gap-1 text-warning font-bold">⭐ {Number(store.rating).toFixed(1)}</span>}
                  <span>🕐 {store.avg_prep_time_min} min</span>
                  <span>{Number(store.delivery_fee) === 0 ? "🟢 Frete grátis" : `🛵 R$ ${Number(store.delivery_fee).toFixed(2)}`}</span>
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
};

export default ExploreCategoryPage;
