import { useState, useEffect } from "react";
import { ArrowLeft, RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

const statusFlow = ["pending", "received", "preparing", "ready", "waiting_driver", "out_for_delivery", "delivered"] as const;
const statusLabels: Record<string, string> = {
  pending: "Pendente", received: "Recebido", preparing: "Preparando", ready: "Pronto",
  waiting_driver: "Aguardando", out_for_delivery: "Em rota", delivered: "Entregue", cancelled: "Cancelado",
};
const statusColors: Record<string, string> = {
  pending: "bg-warning/10 text-warning border-warning/30",
  received: "bg-primary/10 text-primary border-primary/30",
  preparing: "bg-secondary/10 text-secondary border-secondary/30",
  ready: "bg-success/10 text-success border-success/30",
  waiting_driver: "bg-warning/10 text-warning border-warning/30",
  out_for_delivery: "bg-primary/10 text-primary border-primary/30",
  delivered: "bg-success/10 text-success border-success/30",
  cancelled: "bg-destructive/10 text-destructive border-destructive/30",
};

const StoreOrdersPage = () => {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("pending");

  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: store } = useQuery({
    queryKey: ["my-store", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase.from("stores").select("*").eq("owner_id", session!.user.id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: orders, isLoading } = useQuery({
    queryKey: ["store-orders", store?.id, activeTab],
    enabled: !!store?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("*, order_items(*), addresses(*)")
        .eq("store_id", store!.id)
        .eq("status", activeTab as any)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    refetchInterval: 10000,
  });

  const updateStatus = useMutation({
    mutationFn: async ({ orderId, newStatus }: { orderId: string; newStatus: string }) => {
      const { error } = await supabase.from("orders").update({ status: newStatus as any }).eq("id", orderId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["store-orders"] });
      toast.success("Status atualizado!");
    },
  });

  const nextStatus = (current: string) => {
    const idx = statusFlow.indexOf(current as any);
    return idx >= 0 && idx < statusFlow.length - 1 ? statusFlow[idx + 1] : null;
  };

  const tabs = ["pending", "received", "preparing", "ready", "waiting_driver", "out_for_delivery", "delivered", "cancelled"];

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/painel" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Pedidos</h1>
      </header>

      <div className="px-4 py-3 flex gap-2 overflow-x-auto scrollbar-hide">
        {tabs.map((t) => (
          <button key={t} onClick={() => setActiveTab(t)}
            className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${activeTab === t ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            {statusLabels[t]}
          </button>
        ))}
      </div>

      <div className="px-4 space-y-3">
        {isLoading ? (
          <p className="text-center text-sm text-muted-foreground py-8">Carregando...</p>
        ) : !orders || orders.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-8">Nenhum pedido neste status</p>
        ) : (
          orders.map((order) => {
            const next = nextStatus(order.status);
            return (
              <div key={order.id} className={`bg-card rounded-xl p-4 border ${statusColors[order.status] || "border-border"}`}>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <span className="text-xs text-muted-foreground">#{order.id.slice(0, 8)}</span>
                    <p className="text-xs text-muted-foreground">{format(new Date(order.created_at), "HH:mm")}</p>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${statusColors[order.status]}`}>
                    {statusLabels[order.status]}
                  </span>
                </div>
                <div className="space-y-1 mb-3">
                  {(order as any).order_items?.map((item: any) => (
                    <p key={item.id} className="text-xs">{item.quantity}x {item.product_name}</p>
                  ))}
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-sm">R$ {Number(order.total).toFixed(2)}</span>
                  <div className="flex gap-2">
                    {order.status === "pending" && (
                      <Button size="sm" variant="destructive" className="rounded-lg text-xs"
                        onClick={() => updateStatus.mutate({ orderId: order.id, newStatus: "cancelled" })}>
                        Recusar
                      </Button>
                    )}
                    {next && (
                      <Button size="sm" className="rounded-lg text-xs"
                        onClick={() => updateStatus.mutate({ orderId: order.id, newStatus: next })}>
                        → {statusLabels[next]}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default StoreOrdersPage;
