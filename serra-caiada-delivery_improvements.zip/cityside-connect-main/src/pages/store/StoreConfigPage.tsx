import { useState, useEffect } from "react";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";

const StoreConfigPage = () => {
  const queryClient = useQueryClient();
  const [form, setForm] = useState<any>({});

  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: store } = useQuery({
    queryKey: ["my-store", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data } = await supabase.from("stores").select("*").eq("owner_id", session!.user.id).maybeSingle();
      return data;
    },
  });

  useEffect(() => {
    if (store) setForm({
      name: store.name, description: store.description || "", phone: store.phone || "",
      delivery_fee: String(store.delivery_fee || 0), min_order_value: String(store.min_order_value || 0),
      avg_prep_time_min: String(store.avg_prep_time_min || 30), delivery_radius_km: String(store.delivery_radius_km || 10),
      banner_url: store.banner_url || "", logo_url: store.logo_url || "",
      neighborhood: store.neighborhood || "", street: store.street || "",
      is_open: store.is_open ?? false, delivers_own: store.delivers_own ?? false,
    });
  }, [store]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("stores").update({
        name: form.name, description: form.description, phone: form.phone,
        delivery_fee: Number(form.delivery_fee), min_order_value: Number(form.min_order_value),
        avg_prep_time_min: Number(form.avg_prep_time_min), delivery_radius_km: Number(form.delivery_radius_km),
        banner_url: form.banner_url || null, logo_url: form.logo_url || null,
        neighborhood: form.neighborhood, street: form.street,
        is_open: form.is_open, delivers_own: form.delivers_own,
      }).eq("id", store!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-store"] });
      toast.success("Configurações salvas!");
    },
    onError: (e: any) => toast.error(e.message),
  });

  if (!store) return null;

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/painel" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Configurações</h1>
      </header>

      <div className="px-4 py-4 space-y-4">
        <div className="flex items-center justify-between bg-card p-4 rounded-xl">
          <div><h3 className="font-bold text-sm">Loja aberta</h3><p className="text-xs text-muted-foreground">Receber pedidos agora</p></div>
          <Switch checked={form.is_open} onCheckedChange={(v) => setForm({ ...form, is_open: v })} />
        </div>

        <div className="space-y-3">
          <Input placeholder="Nome da loja" value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <Textarea placeholder="Descrição" value={form.description || ""} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} />
          <Input placeholder="Telefone" value={form.phone || ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <Input placeholder="Bairro" value={form.neighborhood || ""} onChange={(e) => setForm({ ...form, neighborhood: e.target.value })} />
          <Input placeholder="Rua" value={form.street || ""} onChange={(e) => setForm({ ...form, street: e.target.value })} />
          <Input placeholder="URL do banner" value={form.banner_url || ""} onChange={(e) => setForm({ ...form, banner_url: e.target.value })} />
          <Input placeholder="URL do logo" value={form.logo_url || ""} onChange={(e) => setForm({ ...form, logo_url: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <Input placeholder="Taxa de entrega" type="number" step="0.01" value={form.delivery_fee || ""} onChange={(e) => setForm({ ...form, delivery_fee: e.target.value })} />
            <Input placeholder="Pedido mínimo" type="number" step="0.01" value={form.min_order_value || ""} onChange={(e) => setForm({ ...form, min_order_value: e.target.value })} />
            <Input placeholder="Tempo preparo (min)" type="number" value={form.avg_prep_time_min || ""} onChange={(e) => setForm({ ...form, avg_prep_time_min: e.target.value })} />
            <Input placeholder="Raio entrega (km)" type="number" value={form.delivery_radius_km || ""} onChange={(e) => setForm({ ...form, delivery_radius_km: e.target.value })} />
          </div>
          <div className="flex items-center justify-between bg-card p-4 rounded-xl">
            <div><h3 className="font-bold text-sm">Entrega própria</h3><p className="text-xs text-muted-foreground">Loja faz suas entregas</p></div>
            <Switch checked={form.delivers_own} onCheckedChange={(v) => setForm({ ...form, delivers_own: v })} />
          </div>
        </div>

        <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="w-full rounded-xl h-12">
          {saveMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Salvar configurações"}
        </Button>
      </div>
    </div>
  );
};

export default StoreConfigPage;
