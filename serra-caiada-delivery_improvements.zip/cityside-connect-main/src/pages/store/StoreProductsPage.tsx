import { useState } from "react";
import { ArrowLeft, Plus, Pencil, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const StoreProductsPage = () => {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", description: "", price: "", category_name: "", image_url: "" });

  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: store } = useQuery({
    queryKey: ["my-store", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data } = await supabase.from("stores").select("*").eq("owner_id", session!.user.id).maybeSingle();
      return data;
    },
  });

  const { data: products, isLoading } = useQuery({
    queryKey: ["store-products", store?.id],
    enabled: !!store?.id,
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").eq("store_id", store!.id).order("sort_order").order("name");
      if (error) throw error;
      return data;
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!store?.id) {
        throw new Error("Sua loja não foi encontrada. Peça ao administrador para aprovar/cadastrar corretamente.");
      }
      const normalizedPrice = String(form.price).replace(",", ".").trim();
      const priceNumber = Number(normalizedPrice);
      if (!Number.isFinite(priceNumber) || priceNumber <= 0) {
        throw new Error("Preço inválido. Exemplo: 15.90");
      }
      const payload = {
        store_id: store!.id,
        name: form.name,
        description: form.description || null,
        price: priceNumber,
        category_name: form.category_name || null,
        image_url: form.image_url || null,
      };
      if (editId) {
        const { error } = await supabase.from("products").update(payload).eq("id", editId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("products").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["store-products"] });
      toast.success(editId ? "Produto atualizado!" : "Produto criado!");
      setOpen(false);
      resetForm();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("products").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["store-products"] });
      toast.success("Produto removido");
    },
  });

  const toggleAvailable = useMutation({
    mutationFn: async ({ id, available }: { id: string; available: boolean }) => {
      const { error } = await supabase.from("products").update({ is_available: available }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["store-products"] }),
  });

  const resetForm = () => { setForm({ name: "", description: "", price: "", category_name: "", image_url: "" }); setEditId(null); };

  const editProduct = (p: any) => {
    setForm({ name: p.name, description: p.description || "", price: String(p.price), category_name: p.category_name || "", image_url: p.image_url || "" });
    setEditId(p.id);
    setOpen(true);
  };

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/painel" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
          <h1 className="text-lg font-bold">Produtos</h1>
        </div>
        <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetForm(); }}>
          <DialogTrigger asChild>
            <Button size="sm" className="rounded-xl gap-1" disabled={!store?.id}><Plus className="w-4 h-4" /> Novo</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editId ? "Editar produto" : "Novo produto"}</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <Input placeholder="Nome" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <Textarea placeholder="Descrição" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} />
              <Input placeholder="Preço (ex: 15.90)" type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
              <Input placeholder="Categoria (ex: Lanches, Bebidas)" value={form.category_name} onChange={(e) => setForm({ ...form, category_name: e.target.value })} />
              <Input placeholder="URL da imagem" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} />
              <Button onClick={() => saveMutation.mutate()} disabled={!form.name || !form.price || saveMutation.isPending} className="w-full rounded-xl">
                {editId ? "Salvar" : "Criar produto"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </header>

      <div className="px-4 py-4 space-y-2">
        {!store?.id && (
          <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-3 text-sm">
            <p className="font-bold text-destructive">Sua loja ainda não está disponível</p>
            <p className="text-xs text-muted-foreground mt-1">
              O painel de produtos só funciona quando o administrador aprovar sua loja.
            </p>
          </div>
        )}
        {isLoading ? <p className="text-center text-muted-foreground py-8 text-sm">Carregando...</p> :
          !products || products.length === 0 ? (
            <p className="text-center text-muted-foreground py-8 text-sm">Nenhum produto cadastrado</p>
          ) : (
            products.map((p) => (
              <div key={p.id} className="bg-card rounded-xl p-3 flex items-center gap-3">
                {p.image_url ? (
                  <img src={p.image_url} alt={p.name} className="w-14 h-14 rounded-lg object-cover shrink-0" />
                ) : (
                  <div className="w-14 h-14 rounded-lg bg-muted flex items-center justify-center text-2xl shrink-0">🍽️</div>
                )}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm truncate">{p.name}</h3>
                  <p className="text-xs text-muted-foreground">{p.category_name || "Sem categoria"} • R$ {Number(p.price).toFixed(2)}</p>
                </div>
                <Switch checked={p.is_available ?? true} onCheckedChange={(v) => toggleAvailable.mutate({ id: p.id, available: v })} />
                <button onClick={() => editProduct(p)} className="p-1.5 text-muted-foreground hover:text-primary"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => deleteMutation.mutate(p.id)} className="p-1.5 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
              </div>
            ))
          )}
      </div>
    </div>
  );
};

export default StoreProductsPage;
