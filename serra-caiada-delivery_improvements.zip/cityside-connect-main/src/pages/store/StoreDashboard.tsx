import { Link } from "react-router-dom";
import { ClipboardList, Package, Clock, Settings, BarChart3, Tag, Truck } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Switch } from "@/components/ui/switch";

const StoreDashboard = () => {
  const queryClient = useQueryClient();

  const { data: session } = useQuery({
    queryKey: ["session"],
    queryFn: async () => { const { data } = await supabase.auth.getSession(); return data.session; },
  });

  const { data: store } = useQuery({
    queryKey: ["my-store", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data } = await supabase.from("stores").select("*").eq("owner_id", session!.user.id).maybeSingle();
      return data;
    },
  });

  const toggleOpen = useMutation({
    mutationFn: async (isOpen: boolean) => {
      if (!store) return;
      await supabase.from("stores").update({ is_open: isOpen }).eq("id", store.id);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["my-store"] }),
  });

  const cards = [
    { icon: ClipboardList, label: "Pedidos", desc: "Pedidos em tempo real", color: "bg-primary/10 text-primary", to: "/painel/pedidos" },
    { icon: Package, label: "Produtos", desc: "Cardápio e itens", color: "bg-secondary/10 text-secondary", to: "/painel/produtos" },
    { icon: Settings, label: "Configurações", desc: "Loja e entrega", color: "bg-muted text-muted-foreground", to: "/painel/config" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground px-6 pt-10 pb-6 rounded-b-3xl">
        <p className="text-xs uppercase tracking-wider opacity-60">Painel</p>
        <h1 className="text-2xl font-extrabold">{store?.name || "Minha Loja"}</h1>
        {store && (
          <div className="flex items-center gap-3 mt-3">
            <Switch checked={store.is_open ?? false} onCheckedChange={(v) => toggleOpen.mutate(v)} />
            <span className="text-sm font-medium">{store.is_open ? "🟢 Aberta" : "🔴 Fechada"}</span>
          </div>
        )}
      </header>

      <div className="px-4 py-6 grid grid-cols-2 gap-3">
        {cards.map((card) => (
          <Link key={card.label} to={card.to}
            className="bg-card rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow">
            <div className={`w-10 h-10 rounded-xl ${card.color} flex items-center justify-center mb-3`}>
              <card.icon className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm">{card.label}</h3>
            <p className="text-xs text-muted-foreground mt-0.5">{card.desc}</p>
          </Link>
        ))}
      </div>

      <div className="px-4">
        <Link to="/" className="text-sm text-primary font-medium">← Voltar ao site</Link>
      </div>
    </div>
  );
};

export default StoreDashboard;
