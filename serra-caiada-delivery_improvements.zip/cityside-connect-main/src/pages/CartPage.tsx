import { ArrowLeft, Trash2, ShoppingBag, Loader2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const CartPage = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: session, isLoading: sessionLoading } = useQuery({
    queryKey: ["session"],
    queryFn: async () => {
      const { data } = await supabase.auth.getSession();
      return data.session;
    },
  });

  const { data: cart, isLoading } = useQuery({
    queryKey: ["user-cart", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("carts")
        .select("*, stores(name, id), cart_items(id, quantity, unit_price, product_id, products(name, price, image_url))")
        .eq("user_id", session!.user.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const items = ((cart as any)?.cart_items || []) as any[];
  const subtotal = items.reduce((acc, it) => acc + Number(it.unit_price) * Number(it.quantity || 1), 0);

  const removeItem = useMutation({
    mutationFn: async (cartItemId: string) => {
      const { error } = await supabase.from("cart_items").delete().eq("id", cartItemId);
      if (error) throw error;
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["user-cart"] });
    },
    onError: (e: any) => toast.error(e.message || "Erro ao remover item"),
  });

  const clearCartIfEmpty = useMutation({
    mutationFn: async () => {
      if (!cart?.id) return;
      const { data, error } = await supabase
        .from("cart_items")
        .select("id")
        .eq("cart_id", cart.id)
        .limit(1);
      if (error) throw error;
      if (!data || data.length === 0) {
        await supabase.from("carts").delete().eq("id", cart.id);
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["user-cart"] }),
  });

  const handleCheckout = () => {
    if (!items.length) {
      toast.error("Seu carrinho está vazio");
      return;
    }
    navigate("/checkout");
  };

  if (sessionLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center">
        <p className="text-lg font-bold mb-4">Faça login para ver seu carrinho</p>
        <Link to="/auth"><Button className="rounded-xl">Entrar</Button></Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-28">
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
        <Link to="/" className="p-2 -ml-2">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="min-w-0">
          <h1 className="text-lg font-bold">Carrinho</h1>
          {(cart as any)?.stores?.name && (
            <p className="text-xs text-muted-foreground truncate">{(cart as any).stores.name}</p>
          )}
        </div>
      </header>

      {!cart || items.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 px-6 text-center">
          <ShoppingBag className="w-16 h-16 text-muted-foreground/30 mb-4" />
          <h2 className="text-lg font-bold text-foreground">Seu carrinho está vazio</h2>
          <p className="text-sm text-muted-foreground mt-1 mb-6">
            Adicione itens de uma loja para começar seu pedido
          </p>
          <Link to="/">
            <Button className="rounded-xl px-8">Explorar lojas</Button>
          </Link>
        </div>
      ) : (
        <div className="px-4 py-4 space-y-3">
          {items.map((it) => (
            <div key={it.id} className="bg-card rounded-2xl p-3 flex items-center gap-3">
              {it.products?.image_url ? (
                <img src={it.products.image_url} alt={it.products?.name} className="w-14 h-14 rounded-xl object-cover" />
              ) : (
                <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center text-xl">🍽️</div>
              )}
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{it.products?.name || "Produto"}</p>
                <p className="text-xs text-muted-foreground">
                  {it.quantity}x • R$ {Number(it.unit_price).toFixed(2)}
                </p>
              </div>
              <button
                className="p-2 rounded-xl hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
                onClick={async () => {
                  await removeItem.mutateAsync(it.id);
                  await clearCartIfEmpty.mutateAsync();
                }}
                aria-label="Remover item"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}

          <div className="fixed bottom-0 left-0 right-0 border-t border-border bg-background/95 backdrop-blur p-4">
            <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
              <div>
                <p className="text-xs text-muted-foreground">Subtotal</p>
                <p className="text-lg font-extrabold">R$ {subtotal.toFixed(2)}</p>
              </div>
              <Button onClick={handleCheckout} className="rounded-2xl h-12 px-6 font-extrabold">
                Continuar
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;
