import { useState, useEffect } from "react";
import { ArrowLeft, Plus, Trash2, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const AdminCityAreaPage = () => {
  const queryClient = useQueryClient();
  const [newNeighborhood, setNewNeighborhood] = useState("");
  const [newZip, setNewZip] = useState("");

  const { data: area } = useQuery({
    queryKey: ["admin-city-area"],
    queryFn: async () => {
      const { data, error } = await supabase.from("city_service_areas").select("*").eq("is_active", true).single();
      if (error) throw error;
      return data;
    },
  });

  const [form, setForm] = useState<any>({});
  useEffect(() => {
    if (area) setForm({
      city_name: area.city_name, state: area.state,
      center_lat: String(area.center_lat || ""), center_lng: String(area.center_lng || ""),
      radius_km: String(area.radius_km || 15),
      neighborhoods: area.neighborhoods || [],
      zip_codes: area.zip_codes || [],
    });
  }, [area]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("city_service_areas").update({
        city_name: form.city_name, state: form.state,
        center_lat: Number(form.center_lat), center_lng: Number(form.center_lng),
        radius_km: Number(form.radius_km),
        neighborhoods: form.neighborhoods, zip_codes: form.zip_codes,
      }).eq("id", area!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-city-area"] });
      toast.success("Área atualizada!");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const addNeighborhood = () => {
    if (!newNeighborhood.trim()) return;
    setForm({ ...form, neighborhoods: [...form.neighborhoods, newNeighborhood.trim()] });
    setNewNeighborhood("");
  };

  const removeNeighborhood = (idx: number) => {
    setForm({ ...form, neighborhoods: form.neighborhoods.filter((_: any, i: number) => i !== idx) });
  };

  const addZip = () => {
    if (!newZip.trim()) return;
    setForm({ ...form, zip_codes: [...form.zip_codes, newZip.trim()] });
    setNewZip("");
  };

  if (!area) return null;

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-foreground text-background px-4 py-3 flex items-center gap-3">
        <Link to="/admin" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Área de atendimento</h1>
      </header>

      <div className="px-4 py-4 space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Input placeholder="Cidade" value={form.city_name || ""} onChange={(e) => setForm({ ...form, city_name: e.target.value })} />
          <Input placeholder="Estado" value={form.state || ""} onChange={(e) => setForm({ ...form, state: e.target.value })} />
          <Input placeholder="Lat centro" value={form.center_lat || ""} onChange={(e) => setForm({ ...form, center_lat: e.target.value })} />
          <Input placeholder="Lng centro" value={form.center_lng || ""} onChange={(e) => setForm({ ...form, center_lng: e.target.value })} />
          <Input placeholder="Raio (km)" type="number" value={form.radius_km || ""} onChange={(e) => setForm({ ...form, radius_km: e.target.value })} className="col-span-2" />
        </div>

        <div>
          <h2 className="font-bold text-sm mb-2">Bairros atendidos</h2>
          <div className="flex gap-2 mb-2">
            <Input placeholder="Nome do bairro" value={newNeighborhood} onChange={(e) => setNewNeighborhood(e.target.value)} className="flex-1" />
            <Button size="sm" onClick={addNeighborhood}><Plus className="w-4 h-4" /></Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {form.neighborhoods?.map((n: string, i: number) => (
              <span key={i} className="flex items-center gap-1 bg-accent text-accent-foreground text-xs px-2 py-1 rounded-full">
                {n}
                <button onClick={() => removeNeighborhood(i)}><Trash2 className="w-3 h-3" /></button>
              </span>
            ))}
          </div>
        </div>

        <div>
          <h2 className="font-bold text-sm mb-2">CEPs atendidos</h2>
          <div className="flex gap-2 mb-2">
            <Input placeholder="CEP" value={newZip} onChange={(e) => setNewZip(e.target.value)} className="flex-1" />
            <Button size="sm" onClick={addZip}><Plus className="w-4 h-4" /></Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {form.zip_codes?.map((z: string, i: number) => (
              <span key={i} className="bg-muted text-muted-foreground text-xs px-2 py-1 rounded-full">{z}</span>
            ))}
          </div>
        </div>

        <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="w-full rounded-xl h-12">
          {saveMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Salvar alterações"}
        </Button>
      </div>
    </div>
  );
};

export default AdminCityAreaPage;
