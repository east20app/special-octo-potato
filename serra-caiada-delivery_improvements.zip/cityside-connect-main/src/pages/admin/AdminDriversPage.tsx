import { ArrowLeft, Check, X, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Input } from "@/components/ui/input";

const AdminDriversPage = () => {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<"all" | "pending" | "approved" | "rejected">("pending");

  const { data: applications, isLoading, error } = useQuery({
    queryKey: ["admin-driver-applications", filter],
    queryFn: async () => {
      let q = supabase
        .from("driver_applications")
        .select("*")
        .order("created_at", { ascending: false });
      if (filter !== "all") q = q.eq("status", filter);
      const { data, error } = await q;
      if (error) {
        if (error.message.includes("does not exist") || error.message.includes("schema cache")) {
          return [];
        }
        throw error;
      }
      return data;
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (app: { id: string; user_id: string }) => {
      // Update application status
      const { error: updateError } = await supabase
        .from("driver_applications")
        .update({ status: "approved" })
        .eq("id", app.id);
      if (updateError) throw updateError;

      // Add delivery_driver role (admin-only via RLS)
      const { error: roleError } = await supabase
        .from("user_roles")
        .insert({ user_id: app.user_id, role: "delivery_driver" });
      if (roleError && !roleError.message.includes("duplicate")) throw roleError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-driver-applications"] });
      toast.success("Entregador aprovado!");
    },
    onError: (err: any) => toast.error(err.message || "Erro ao aprovar"),
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason?: string }) => {
      const { error } = await supabase
        .from("driver_applications")
        .update({ status: "rejected", rejection_reason: reason || null })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-driver-applications"] });
      toast.success("Solicitação recusada");
    },
    onError: (err: any) => toast.error(err.message || "Erro ao recusar"),
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-foreground text-background px-4 py-3 flex items-center gap-3">
        <Link to="/admin" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Entregadores</h1>
      </header>

      <div className="px-4 py-3 flex gap-2 overflow-x-auto">
        {(["pending", "approved", "rejected", "all"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${filter === f ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            {f === "all" ? "Todas" : f === "pending" ? "Pendentes" : f === "approved" ? "Aprovados" : "Recusados"}
          </button>
        ))}
      </div>

      <div className="px-4 space-y-3">
        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : error ? (
          <p className="text-center text-destructive py-8 text-sm">Erro ao carregar dados</p>
        ) : !applications || applications.length === 0 ? (
          <p className="text-center text-muted-foreground py-8 text-sm">Nenhuma solicitação encontrada</p>
        ) : (
          applications.map((app: any) => (
            <div key={app.id} className="bg-card rounded-xl p-4 border border-border">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-sm">{app.full_name || "Sem nome"}</h3>
                  <p className="text-xs text-muted-foreground">{app.phone || "Sem telefone"} • {app.vehicle || "moto"}</p>
                  {app.document && <p className="text-xs text-muted-foreground">Doc: {app.document}</p>}
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {new Date(app.created_at).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  app.status === "approved" ? "bg-success/10 text-success" :
                  app.status === "rejected" ? "bg-destructive/10 text-destructive" :
                  "bg-warning/10 text-warning"
                }`}>
                  {app.status === "approved" ? "Aprovado" : app.status === "rejected" ? "Recusado" : "Pendente"}
                </span>
              </div>
              {app.status === "pending" && (
                <div className="flex gap-2 mt-3">
                  <Button size="sm" className="rounded-lg text-xs gap-1 flex-1"
                    onClick={() => approveMutation.mutate({ id: app.id, user_id: app.user_id })}
                    disabled={approveMutation.isPending}>
                    <Check className="w-3 h-3" /> Aprovar
                  </Button>
                  <Button size="sm" variant="destructive" className="rounded-lg text-xs gap-1 flex-1"
                    onClick={() => rejectMutation.mutate({ id: app.id })}
                    disabled={rejectMutation.isPending}>
                    <X className="w-3 h-3" /> Recusar
                  </Button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminDriversPage;
