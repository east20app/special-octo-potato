import { Link } from "react-router-dom";
import { LayoutDashboard, Store, Users, Truck, Settings, BarChart3, Tag, MapPin } from "lucide-react";

const AdminDashboard = () => {
  const cards = [
    { icon: BarChart3, label: "Relatórios", desc: "Vendas e métricas", color: "bg-accent text-accent-foreground", to: "/admin/relatorios" },
    { icon: Store, label: "Lojas", desc: "Aprovar e gerenciar", color: "bg-secondary/10 text-secondary", to: "/admin/lojas" },
    { icon: Truck, label: "Entregadores", desc: "Aprovar e monitorar", color: "bg-warning/10 text-warning", to: "/admin/entregadores" },
    { icon: LayoutDashboard, label: "Pedidos", desc: "Monitorar pedidos", color: "bg-primary/10 text-primary", to: "/admin/pedidos" },
    { icon: Tag, label: "Cupons", desc: "Gerenciar promoções", color: "bg-destructive/10 text-destructive", to: "/admin/cupons" },
    { icon: MapPin, label: "Área da cidade", desc: "Bairros e CEPs", color: "bg-success/10 text-success", to: "/admin/area-cidade" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-foreground text-background px-6 pt-10 pb-6 rounded-b-3xl">
        <p className="text-xs uppercase tracking-wider opacity-60">Painel</p>
        <h1 className="text-2xl font-extrabold">Administrador</h1>
      </header>

      <div className="px-4 py-6 grid grid-cols-2 gap-3">
        {cards.map((card) => (
          <Link key={card.label} to={card.to}
            className="bg-card rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow">
            <div className={`w-10 h-10 rounded-xl ${card.color} flex items-center justify-center mb-3`}>
              <card.icon className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm">{card.label}</h3>
            <p className="text-xs text-muted-foreground mt-0.5">{card.desc}</p>
          </Link>
        ))}
      </div>

      <div className="px-4">
        <Link to="/" className="text-sm text-primary font-medium">← Voltar ao site</Link>
      </div>
    </div>
  );
};

export default AdminDashboard;
