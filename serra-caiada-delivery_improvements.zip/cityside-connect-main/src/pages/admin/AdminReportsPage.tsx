import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

const AdminReportsPage = () => {
  const { data: stats } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [orders, stores, deliveries] = await Promise.all([
        supabase.from("orders").select("id, total, status", { count: "exact" }),
        supabase.from("stores").select("id", { count: "exact" }),
        supabase.from("deliveries").select("id, status", { count: "exact" }),
      ]);
      const allOrders = orders.data || [];
      const totalRevenue = allOrders.filter(o => o.status === "delivered").reduce((acc, o) => acc + Number(o.total), 0);
      const delivered = allOrders.filter(o => o.status === "delivered").length;
      const cancelled = allOrders.filter(o => o.status === "cancelled").length;
      return {
        totalOrders: orders.count || 0,
        totalStores: stores.count || 0,
        totalDeliveries: deliveries.count || 0,
        totalRevenue,
        delivered,
        cancelled,
      };
    },
  });

  const cards = [
    { label: "Pedidos totais", value: stats?.totalOrders || 0, icon: "📦" },
    { label: "Receita total", value: `R$ ${(stats?.totalRevenue || 0).toFixed(2)}`, icon: "💰" },
    { label: "Entregues", value: stats?.delivered || 0, icon: "✅" },
    { label: "Cancelados", value: stats?.cancelled || 0, icon: "❌" },
    { label: "Lojas", value: stats?.totalStores || 0, icon: "🏪" },
    { label: "Entregas", value: stats?.totalDeliveries || 0, icon: "🛵" },
  ];

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-foreground text-background px-4 py-3 flex items-center gap-3">
        <Link to="/admin" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Relatórios</h1>
      </header>

      <div className="px-4 py-4 grid grid-cols-2 gap-3">
        {cards.map((card) => (
          <div key={card.label} className="bg-card rounded-2xl p-4 text-center shadow-sm">
            <span className="text-2xl">{card.icon}</span>
            <p className="text-lg font-extrabold mt-1">{card.value}</p>
            <p className="text-xs text-muted-foreground">{card.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminReportsPage;
