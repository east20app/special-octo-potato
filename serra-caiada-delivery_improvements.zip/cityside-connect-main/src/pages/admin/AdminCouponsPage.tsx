import { useState } from "react";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const AdminCouponsPage = () => {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ code: "", discount_type: "percentage" as "percentage" | "fixed", discount_value: "", min_order_value: "", max_uses: "" });

  const { data: coupons, isLoading } = useQuery({
    queryKey: ["admin-coupons"],
    queryFn: async () => {
      const { data, error } = await supabase.from("coupons").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("coupons").insert({
        code: form.code.toUpperCase(),
        discount_type: form.discount_type,
        discount_value: Number(form.discount_value),
        min_order_value: form.min_order_value ? Number(form.min_order_value) : null,
        max_uses: form.max_uses ? Number(form.max_uses) : null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-coupons"] });
      toast.success("Cupom criado!");
      setOpen(false);
      setForm({ code: "", discount_type: "percentage", discount_value: "", min_order_value: "", max_uses: "" });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from("coupons").update({ is_active: active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-coupons"] }),
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-foreground text-background px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/admin" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
          <h1 className="text-lg font-bold">Cupons</h1>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" variant="secondary" className="rounded-xl gap-1"><Plus className="w-4 h-4" /> Novo</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Novo cupom</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <Input placeholder="Código (ex: BEMVINDO)" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
              <Select value={form.discount_type} onValueChange={(v: any) => setForm({ ...form, discount_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="percentage">Porcentagem (%)</SelectItem>
                  <SelectItem value="fixed">Valor fixo (R$)</SelectItem>
                </SelectContent>
              </Select>
              <Input placeholder="Valor do desconto" type="number" value={form.discount_value} onChange={(e) => setForm({ ...form, discount_value: e.target.value })} />
              <Input placeholder="Pedido mínimo (opcional)" type="number" value={form.min_order_value} onChange={(e) => setForm({ ...form, min_order_value: e.target.value })} />
              <Input placeholder="Máx. usos (opcional)" type="number" value={form.max_uses} onChange={(e) => setForm({ ...form, max_uses: e.target.value })} />
              <Button onClick={() => createMutation.mutate()} disabled={!form.code || !form.discount_value} className="w-full rounded-xl">Criar cupom</Button>
            </div>
          </DialogContent>
        </Dialog>
      </header>

      <div className="px-4 py-4 space-y-3">
        {isLoading ? <p className="text-center text-muted-foreground py-8 text-sm">Carregando...</p> :
          coupons?.map((c) => (
            <div key={c.id} className="bg-card rounded-xl p-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm font-mono">{c.code}</h3>
                <p className="text-xs text-muted-foreground">
                  {c.discount_type === "percentage" ? `${c.discount_value}%` : `R$ ${Number(c.discount_value).toFixed(2)}`}
                  {c.min_order_value && Number(c.min_order_value) > 0 ? ` • Mín R$ ${Number(c.min_order_value).toFixed(2)}` : ""}
                  {c.max_uses ? ` • ${c.used_count}/${c.max_uses} usos` : ""}
                </p>
              </div>
              <Switch checked={c.is_active ?? true} onCheckedChange={(v) => toggleActive.mutate({ id: c.id, active: v })} />
            </div>
          ))}
      </div>
    </div>
  );
};

export default AdminCouponsPage;
