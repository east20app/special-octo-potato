import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { useState } from "react";

const statusLabels: Record<string, string> = {
  pending: "Pendente", received: "Recebido", preparing: "Preparando", ready: "Pronto",
  waiting_driver: "Aguardando", out_for_delivery: "Em rota", delivered: "Entregue", cancelled: "Cancelado",
};

const AdminOrdersPage = () => {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: orders, isLoading } = useQuery({
    queryKey: ["admin-orders", statusFilter],
    queryFn: async () => {
      let q = supabase.from("orders").select("*, stores(name)").order("created_at", { ascending: false }).limit(50);
      if (statusFilter !== "all") q = q.eq("status", statusFilter as any);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });

  const cancelOrder = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("orders").update({ status: "cancelled" }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-orders"] });
      toast.success("Pedido cancelado");
    },
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-foreground text-background px-4 py-3 flex items-center gap-3">
        <Link to="/admin" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Pedidos</h1>
      </header>

      <div className="px-4 py-3 flex gap-2 overflow-x-auto scrollbar-hide">
        {["all", ...Object.keys(statusLabels)].map((s) => (
          <button key={s} onClick={() => setStatusFilter(s)}
            className={`text-xs px-3 py-1.5 rounded-full border whitespace-nowrap ${statusFilter === s ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            {s === "all" ? "Todos" : statusLabels[s]}
          </button>
        ))}
      </div>

      <div className="px-4 space-y-3">
        {isLoading ? <p className="text-center text-muted-foreground py-8 text-sm">Carregando...</p> :
          orders?.map((order) => (
            <div key={order.id} className="bg-card rounded-xl p-4 border border-border">
              <div className="flex justify-between items-start mb-1">
                <div>
                  <span className="text-xs text-muted-foreground">#{order.id.slice(0, 8)}</span>
                  <h3 className="font-bold text-sm">{(order as any).stores?.name}</h3>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-muted">{statusLabels[order.status]}</span>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-xs text-muted-foreground">{format(new Date(order.created_at), "dd/MM HH:mm")}</span>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm">R$ {Number(order.total).toFixed(2)}</span>
                  {order.status !== "cancelled" && order.status !== "delivered" && (
                    <Button size="sm" variant="destructive" className="rounded-lg text-xs"
                      onClick={() => cancelOrder.mutate(order.id)}>Cancelar</Button>
                  )}
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default AdminOrdersPage;
