import { ArrowLeft, Check, X, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";

const AdminStoresPage = () => {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<"all" | "pending" | "approved">("pending");

  const { data: stores, isLoading, error } = useQuery({
    queryKey: ["admin-stores", filter],
    queryFn: async () => {
      let q = supabase.from("stores").select("*, categories(name)").order("created_at", { ascending: false });
      if (filter === "pending") q = q.eq("is_approved", false);
      if (filter === "approved") q = q.eq("is_approved", true);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });

  const toggleApproval = useMutation({
    mutationFn: async ({ id, approved, owner_id }: { id: string; approved: boolean; owner_id: string }) => {
      const { error } = await supabase.from("stores").update({ is_approved: approved }).eq("id", id);
      if (error) throw error;
      // If approving, also add store_owner role
      if (approved) {
        const { error: roleError } = await supabase
          .from("user_roles")
          .insert({ user_id: owner_id, role: "store_owner" });
        if (roleError && !roleError.message.includes("duplicate")) throw roleError;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-stores"] });
      toast.success("Atualizado!");
    },
    onError: (err: any) => toast.error(err.message || "Erro"),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from("stores").update({ is_active: active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-stores"] }),
  });

  return (
    <div className="min-h-screen bg-background pb-6">
      <header className="sticky top-0 z-30 bg-foreground text-background px-4 py-3 flex items-center gap-3">
        <Link to="/admin" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-lg font-bold">Lojas</h1>
      </header>

      <div className="px-4 py-3 flex gap-2">
        {(["pending", "approved", "all"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`text-xs px-3 py-1.5 rounded-full border ${filter === f ? "bg-primary text-primary-foreground border-primary" : "border-border"}`}>
            {f === "all" ? "Todas" : f === "pending" ? "Pendentes" : "Aprovadas"}
          </button>
        ))}
      </div>

      <div className="px-4 space-y-3">
        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : error ? (
          <p className="text-center text-destructive py-8 text-sm">Erro ao carregar lojas</p>
        ) : !stores || stores.length === 0 ? (
          <p className="text-center text-muted-foreground py-8 text-sm">Nenhuma loja encontrada</p>
        ) : (
          stores.map((store) => (
            <div key={store.id} className="bg-card rounded-xl p-4 border border-border">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-sm">{store.name}</h3>
                  <p className="text-xs text-muted-foreground">{(store.categories as any)?.name} • {store.neighborhood}</p>
                  <p className="text-[10px] text-muted-foreground">{store.phone}</p>
                </div>
                <div className="flex items-center gap-2">
                  {!store.is_approved ? (
                    <Button size="sm" className="rounded-lg text-xs gap-1"
                      onClick={() => toggleApproval.mutate({ id: store.id, approved: true, owner_id: store.owner_id })}
                      disabled={toggleApproval.isPending}>
                      <Check className="w-3 h-3" /> Aprovar
                    </Button>
                  ) : (
                    <Button size="sm" variant="destructive" className="rounded-lg text-xs gap-1"
                      onClick={() => toggleApproval.mutate({ id: store.id, approved: false, owner_id: store.owner_id })}
                      disabled={toggleApproval.isPending}>
                      <X className="w-3 h-3" /> Reprovar
                    </Button>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${store.is_approved ? "bg-success/10 text-success" : "bg-warning/10 text-warning"}`}>
                  {store.is_approved ? "Aprovada" : "Pendente"}
                </span>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>Ativa</span>
                  <Switch checked={store.is_active ?? true} onCheckedChange={(v) => toggleActive.mutate({ id: store.id, active: v })} />
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminStoresPage;
