import { ArrowLeft, HelpCircle, ChevronDown } from "lucide-react";
import { Link } from "react-router-dom";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import Footer from "@/components/Footer";

const faqs = [
  { q: "Como faço um pedido?", a: "Escolha uma loja, adicione itens ao carrinho, selecione o endereço e forma de pagamento, e confirme o pedido." },
  { q: "Quais formas de pagamento são aceitas?", a: "Aceitamos PIX, cartão de crédito/débito e dinheiro na entrega." },
  { q: "Posso cancelar meu pedido?", a: "Sim, antes da loja iniciar o preparo. Após isso, podem haver taxas de cancelamento." },
  { q: "O serviço funciona em outras cidades?", a: "Não, atualmente o SC Delivery funciona exclusivamente em Serra Caiada - RN." },
  { q: "Como acompanho meu pedido?", a: "Na tela de acompanhamento você vê o status em tempo real: recebido, preparando, pronto, saiu para entrega e entregue." },
  { q: "Como me torno um entregador?", a: "Acesse a página 'Seja um Entregador', preencha o formulário com seus dados e aguarde a aprovação do admin." },
  { q: "Como cadastro minha loja?", a: "Acesse a página 'Seja um Parceiro', preencha o formulário com os dados da loja e aguarde a aprovação." },
  { q: "Tem taxa de entrega?", a: "A taxa varia de acordo com a loja e a distância. Algumas lojas oferecem frete grátis." },
];

const HelpPage = () => (
  <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
      <Link to="/" className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></Link>
      <h1 className="text-lg font-bold">Central de Ajuda</h1>
    </header>
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-card rounded-2xl p-6 text-center mb-6">
        <HelpCircle className="w-12 h-12 mx-auto mb-3 text-primary" />
        <h2 className="text-lg font-bold">Perguntas frequentes</h2>
        <p className="text-sm text-muted-foreground mt-1">Encontre respostas para as dúvidas mais comuns</p>
      </div>

      <Accordion type="single" collapsible className="space-y-2">
        {faqs.map((faq, i) => (
          <AccordionItem key={i} value={`faq-${i}`} className="bg-card rounded-xl border-none px-4">
            <AccordionTrigger className="text-sm font-semibold hover:no-underline py-4">{faq.q}</AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground pb-4">{faq.a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>

      <div className="mt-8 text-center">
        <p className="text-sm text-muted-foreground mb-3">Não encontrou o que procura?</p>
        <Link to="/contato" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-xl text-sm font-bold hover:bg-primary/90 transition-colors">
          Falar com suporte
        </Link>
      </div>
    </div>
    <Footer />
  </div>
);

export default HelpPage;
