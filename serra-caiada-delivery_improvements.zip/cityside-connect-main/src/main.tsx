import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import EnvMissing from "./components/EnvMissing";

const hasEnv = Boolean(import.meta.env.VITE_SUPABASE_URL) && Boolean(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY);

createRoot(document.getElementById("root")!).render(hasEnv ? <App /> : <EnvMissing />);
