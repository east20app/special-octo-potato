import { Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Clock } from "lucide-react";
import { Link } from "react-router-dom";

const StoreOwnerRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isLoading, hasRole, isRolesLoading } = useAuth();

  const { data: store, isLoading: storeLoading } = useQuery({
    queryKey: ["my-store-check", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("stores")
        .select("id, is_approved, name")
        .eq("owner_id", user!.id)
        .maybeSingle();
      return data;
    },
  });

  if (isLoading || isRolesLoading || storeLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) return <Navigate to="/auth" replace />;

  if (hasRole("admin")) return <>{children}</>;

  if (store && !store.is_approved) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background px-6 text-center">
        <Clock className="w-16 h-16 text-warning mb-4" />
        <h1 className="text-2xl font-extrabold mb-2">Sua loja está em análise</h1>
        <p className="text-muted-foreground mb-6">
          Aguarde a aprovação do administrador para acessar o painel.
        </p>
        <Link to="/" className="text-primary font-bold">← Voltar ao início</Link>
      </div>
    );
  }

  // Having a role without an actual store record should not grant access.
  if (!store) {
    return <Navigate to="/nao-autorizado" replace />;
  }

  return <>{children}</>;
};

export default StoreOwnerRoute;
