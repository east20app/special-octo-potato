import { Link } from "react-router-dom";
import { usePwaInstall } from "@/hooks/usePwaInstall";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Download, Share } from "lucide-react";
import { Button } from "@/components/ui/button";

const footerLinks = {
  institucional: [
    { label: "Sobre nós", to: "/sobre" },
    { label: "Trabalhe conosco", to: "/sobre" },
    { label: "Termos de uso", to: "/termos" },
    { label: "Privacidade", to: "/privacidade" },
    { label: "Segurança", to: "/seguranca" },
  ],
  paraVoce: [
    { label: "Central de ajuda", to: "/ajuda" },
    { label: "Contato", to: "/contato" },
    { label: "Suporte", to: "/suporte" },
  ],
  paraLojas: [
    { label: "Seja parceiro", to: "/seja-parceiro" },
    { label: "Painel do lojista", to: "/painel" },
    { label: "Regras e comissões", to: "/termos" },
  ],
  paraEntregadores: [
    { label: "Seja entregador", to: "/seja-entregador" },
    { label: "Painel do entregador", to: "/entregador" },
    { label: "Regras e ganhos", to: "/termos" },
  ],
};

interface FooterProps {
  neighborhoods?: string[];
}

const Footer = ({ neighborhoods = [] }: FooterProps) => {
  const { canInstall, install, showIosModal, setShowIosModal, isStandalone } = usePwaInstall();

  return (
    <footer className="bg-foreground text-background mt-8">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          <div>
            <h4 className="font-bold text-sm mb-3 opacity-60 uppercase tracking-wider">Institucional</h4>
            <ul className="space-y-2">
              {footerLinks.institucional.map((l) => (
                <li key={l.label}><Link to={l.to} className="text-sm opacity-80 hover:opacity-100 transition-opacity">{l.label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-sm mb-3 opacity-60 uppercase tracking-wider">Para você</h4>
            <ul className="space-y-2">
              {footerLinks.paraVoce.map((l) => (
                <li key={l.label}><Link to={l.to} className="text-sm opacity-80 hover:opacity-100 transition-opacity">{l.label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-sm mb-3 opacity-60 uppercase tracking-wider">Para lojas</h4>
            <ul className="space-y-2">
              {footerLinks.paraLojas.map((l) => (
                <li key={l.label}><Link to={l.to} className="text-sm opacity-80 hover:opacity-100 transition-opacity">{l.label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-sm mb-3 opacity-60 uppercase tracking-wider">Para entregadores</h4>
            <ul className="space-y-2">
              {footerLinks.paraEntregadores.map((l) => (
                <li key={l.label}><Link to={l.to} className="text-sm opacity-80 hover:opacity-100 transition-opacity">{l.label}</Link></li>
              ))}
            </ul>
          </div>
          <div className="col-span-2">
            <h4 className="font-bold text-sm mb-3 opacity-60 uppercase tracking-wider">Cidade</h4>
            <p className="text-sm font-semibold mb-2">🏙️ Serviço disponível somente em Serra Caiada – RN</p>
            {neighborhoods.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {neighborhoods.map((n) => (
                  <span key={n} className="text-[10px] bg-background/10 px-2 py-0.5 rounded-full">{n}</span>
                ))}
              </div>
            )}
            {!isStandalone && (
              <div className="mt-4">
                <Button
                  onClick={install}
                  variant="default"
                  className="rounded-xl text-sm font-bold gap-2"
                >
                  <Download className="w-4 h-4" />
                  {canInstall ? "Instalar App" : "Instalar App"}
                </Button>
                {!canInstall && (
                  <p className="text-[11px] opacity-70 mt-2">
                    Se o botão não abrir, use o menu do navegador e escolha “Instalar app”.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-background/10 mt-8 pt-6 text-center">
          <p className="text-xs opacity-50">© {new Date().getFullYear()} Serra Caiada Delivery. Todos os direitos reservados.</p>
        </div>
      </div>

      {/* iOS install modal */}
      <Dialog open={showIosModal} onOpenChange={setShowIosModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Instalar no iPhone/iPad</DialogTitle>
            <DialogDescription>
              Para instalar o app no seu dispositivo Apple:
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex items-center gap-3">
              <span className="bg-primary/10 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold text-primary">1</span>
              <p className="text-sm">Toque no botão <Share className="w-4 h-4 inline" /> <strong>Compartilhar</strong> na barra do Safari</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="bg-primary/10 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold text-primary">2</span>
              <p className="text-sm">Role para baixo e toque em <strong>"Adicionar à Tela de Início"</strong></p>
            </div>
            <div className="flex items-center gap-3">
              <span className="bg-primary/10 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold text-primary">3</span>
              <p className="text-sm">Toque em <strong>"Adicionar"</strong> para confirmar</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </footer>
  );
};

export default Footer;
