import React from "react";

export default function EnvMissing() {
  return (
    <div style={{ fontFamily: "system-ui, Arial", padding: 24, maxWidth: 760, margin: "0 auto" }}>
      <h1 style={{ fontSize: 22, marginBottom: 8 }}>Configuração necessária</h1>
      <p style={{ marginBottom: 12 }}>
        O site não conseguiu iniciar porque faltam variáveis de ambiente do Supabase.
      </p>
      <div style={{ background: "#111827", color: "#e5e7eb", padding: 16, borderRadius: 8, overflowX: "auto" }}>
        <pre style={{ margin: 0 }}>VITE_SUPABASE_URL=...
VITE_SUPABASE_PUBLISHABLE_KEY=...</pre>
      </div>
      <p style={{ marginTop: 12 }}>
        Configure isso no arquivo <b>.env</b> (desenvolvimento) ou no painel da sua hospedagem (produção) e recarregue a página.
      </p>
    </div>
  );
}
