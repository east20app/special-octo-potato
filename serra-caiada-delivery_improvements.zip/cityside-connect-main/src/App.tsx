import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import ProtectedRoute from "@/components/ProtectedRoute";
import StoreOwnerRoute from "@/components/StoreOwnerRoute";
import Index from "./pages/Index";
import StorePage from "./pages/StorePage";
import CartPage from "./pages/CartPage";
import AuthPage from "./pages/AuthPage";
import OrderTrackingPage from "./pages/OrderTrackingPage";
import ProfilePage from "./pages/ProfilePage";
import LocationPage from "./pages/LocationPage";
import SearchPage from "./pages/SearchPage";
import ExploreCategoryPage from "./pages/ExploreCategoryPage";
import CheckoutPage from "./pages/CheckoutPage";
import OrdersHistoryPage from "./pages/OrdersHistoryPage";
import FavoritesPage from "./pages/FavoritesPage";
import AddressesPage from "./pages/AddressesPage";
import SupportPage from "./pages/SupportPage";
import AboutPage from "./pages/AboutPage";
import TermsPage from "./pages/TermsPage";
import PrivacyPage from "./pages/PrivacyPage";
import SecurityPage from "./pages/SecurityPage";
import ContactPage from "./pages/ContactPage";
import HelpPage from "./pages/HelpPage";
import BecomeDriverPage from "./pages/BecomeDriverPage";
import BecomePartnerPage from "./pages/BecomePartnerPage";
import UnauthorizedPage from "./pages/UnauthorizedPage";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminStoresPage from "./pages/admin/AdminStoresPage";
import AdminDriversPage from "./pages/admin/AdminDriversPage";
import AdminOrdersPage from "./pages/admin/AdminOrdersPage";
import AdminCouponsPage from "./pages/admin/AdminCouponsPage";
import AdminCityAreaPage from "./pages/admin/AdminCityAreaPage";
import AdminReportsPage from "./pages/admin/AdminReportsPage";
import StoreDashboard from "./pages/store/StoreDashboard";
import StoreOrdersPage from "./pages/store/StoreOrdersPage";
import StoreProductsPage from "./pages/store/StoreProductsPage";
import StoreConfigPage from "./pages/store/StoreConfigPage";
import DriverDashboard from "./pages/driver/DriverDashboard";
import DriverOffersPage from "./pages/driver/DriverOffersPage";
import DriverDeliveryPage from "./pages/driver/DriverDeliveryPage";
import DriverHistoryPage from "./pages/driver/DriverHistoryPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public */}
            <Route path="/" element={<Index />} />
            <Route path="/localizacao" element={<LocationPage />} />
            <Route path="/buscar" element={<SearchPage />} />
            <Route path="/explorar/:categorySlug" element={<ExploreCategoryPage />} />
            <Route path="/loja/:storeId" element={<StorePage />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/nao-autorizado" element={<UnauthorizedPage />} />
            {/* Institutional */}
            <Route path="/sobre" element={<AboutPage />} />
            <Route path="/termos" element={<TermsPage />} />
            <Route path="/privacidade" element={<PrivacyPage />} />
            <Route path="/seguranca" element={<SecurityPage />} />
            <Route path="/contato" element={<ContactPage />} />
            <Route path="/ajuda" element={<HelpPage />} />
            {/* Onboarding */}
            <Route path="/seja-entregador" element={<BecomeDriverPage />} />
            <Route path="/seja-parceiro" element={<BecomePartnerPage />} />
            {/* Client (requires login) */}
            <Route path="/carrinho" element={<ProtectedRoute><CartPage /></ProtectedRoute>} />
            <Route path="/checkout" element={<ProtectedRoute><CheckoutPage /></ProtectedRoute>} />
            <Route path="/pedido/:orderId" element={<ProtectedRoute><OrderTrackingPage /></ProtectedRoute>} />
            <Route path="/pedidos" element={<ProtectedRoute><OrdersHistoryPage /></ProtectedRoute>} />
            <Route path="/favoritos" element={<ProtectedRoute><FavoritesPage /></ProtectedRoute>} />
            <Route path="/perfil" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
            <Route path="/enderecos" element={<ProtectedRoute><AddressesPage /></ProtectedRoute>} />
            <Route path="/suporte" element={<ProtectedRoute><SupportPage /></ProtectedRoute>} />
            {/* Admin */}
            <Route path="/admin" element={<ProtectedRoute requiredRole="admin"><AdminDashboard /></ProtectedRoute>} />
            <Route path="/admin/lojas" element={<ProtectedRoute requiredRole="admin"><AdminStoresPage /></ProtectedRoute>} />
            <Route path="/admin/entregadores" element={<ProtectedRoute requiredRole="admin"><AdminDriversPage /></ProtectedRoute>} />
            <Route path="/admin/pedidos" element={<ProtectedRoute requiredRole="admin"><AdminOrdersPage /></ProtectedRoute>} />
            <Route path="/admin/cupons" element={<ProtectedRoute requiredRole="admin"><AdminCouponsPage /></ProtectedRoute>} />
            <Route path="/admin/area-cidade" element={<ProtectedRoute requiredRole="admin"><AdminCityAreaPage /></ProtectedRoute>} />
            <Route path="/admin/relatorios" element={<ProtectedRoute requiredRole="admin"><AdminReportsPage /></ProtectedRoute>} />
            {/* Store Panel */}
            <Route path="/painel" element={<StoreOwnerRoute><StoreDashboard /></StoreOwnerRoute>} />
            <Route path="/painel/pedidos" element={<StoreOwnerRoute><StoreOrdersPage /></StoreOwnerRoute>} />
            <Route path="/painel/produtos" element={<StoreOwnerRoute><StoreProductsPage /></StoreOwnerRoute>} />
            <Route path="/painel/config" element={<StoreOwnerRoute><StoreConfigPage /></StoreOwnerRoute>} />
            {/* Driver */}
            <Route path="/entregador" element={<ProtectedRoute requiredRole="delivery_driver"><DriverDashboard /></ProtectedRoute>} />
            <Route path="/entregador/ofertas" element={<ProtectedRoute requiredRole="delivery_driver"><DriverOffersPage /></ProtectedRoute>} />
            <Route path="/entregador/entrega/:deliveryId" element={<ProtectedRoute requiredRole="delivery_driver"><DriverDeliveryPage /></ProtectedRoute>} />
            <Route path="/entregador/historico" element={<ProtectedRoute requiredRole="delivery_driver"><DriverHistoryPage /></ProtectedRoute>} />
            {/* Fallback */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
