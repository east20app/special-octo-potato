
-- ============================================
-- DELIVERY MARKETPLACE - SERRA CAIADA RN
-- ============================================

-- 1. ENUM TYPES
CREATE TYPE public.app_role AS ENUM ('customer', 'store_owner', 'delivery_driver', 'admin');
CREATE TYPE public.store_mode AS ENUM ('food', 'market', 'both');
CREATE TYPE public.order_status AS ENUM ('pending', 'received', 'preparing', 'ready', 'waiting_driver', 'out_for_delivery', 'delivered', 'cancelled');
CREATE TYPE public.delivery_status AS ENUM ('pending', 'accepted', 'picked_up', 'delivered', 'cancelled');
CREATE TYPE public.payment_method AS ENUM ('pix', 'card', 'cash');
CREATE TYPE public.payment_status AS ENUM ('pending', 'paid', 'refunded');
CREATE TYPE public.discount_type AS ENUM ('percentage', 'fixed');

-- 2. PROFILES TABLE
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  full_name TEXT NOT NULL DEFAULT '',
  phone TEXT,
  avatar_url TEXT,
  cpf TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 3. USER ROLES TABLE
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'customer',
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 4. CITY SERVICE AREAS
CREATE TABLE public.city_service_areas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  city_name TEXT NOT NULL DEFAULT 'Serra Caiada',
  state TEXT NOT NULL DEFAULT 'RN',
  neighborhoods TEXT[] NOT NULL DEFAULT '{}',
  zip_codes TEXT[] NOT NULL DEFAULT '{}',
  center_lat DOUBLE PRECISION DEFAULT -6.1053,
  center_lng DOUBLE PRECISION DEFAULT -35.7133,
  radius_km DOUBLE PRECISION DEFAULT 15,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.city_service_areas ENABLE ROW LEVEL SECURITY;

-- 5. ADDRESSES
CREATE TABLE public.addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  label TEXT DEFAULT 'Casa',
  street TEXT NOT NULL,
  number TEXT,
  complement TEXT,
  neighborhood TEXT NOT NULL,
  city TEXT NOT NULL DEFAULT 'Serra Caiada',
  state TEXT NOT NULL DEFAULT 'RN',
  zip_code TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.addresses ENABLE ROW LEVEL SECURITY;

-- 6. CATEGORIES
CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  icon TEXT,
  mode store_mode NOT NULL DEFAULT 'both',
  sort_order INT DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- 7. STORES
CREATE TABLE public.stores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  slug TEXT UNIQUE,
  mode store_mode NOT NULL DEFAULT 'food',
  category_id UUID REFERENCES public.categories(id),
  logo_url TEXT,
  banner_url TEXT,
  phone TEXT,
  street TEXT,
  neighborhood TEXT,
  city TEXT DEFAULT 'Serra Caiada',
  state TEXT DEFAULT 'RN',
  zip_code TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  min_order_value DECIMAL(10,2) DEFAULT 0,
  delivery_fee DECIMAL(10,2) DEFAULT 0,
  delivery_radius_km DOUBLE PRECISION DEFAULT 10,
  avg_prep_time_min INT DEFAULT 30,
  rating DECIMAL(3,2) DEFAULT 0,
  total_reviews INT DEFAULT 0,
  is_open BOOLEAN DEFAULT false,
  is_approved BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  delivers_own BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;

-- 8. STORE HOURS
CREATE TABLE public.store_hours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE NOT NULL,
  day_of_week INT NOT NULL, -- 0=Sunday..6=Saturday
  open_time TIME NOT NULL DEFAULT '08:00',
  close_time TIME NOT NULL DEFAULT '22:00',
  is_closed BOOLEAN DEFAULT false
);
ALTER TABLE public.store_hours ENABLE ROW LEVEL SECURITY;

-- 9. PRODUCTS
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE NOT NULL,
  category_name TEXT,
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  image_url TEXT,
  is_available BOOLEAN DEFAULT true,
  stock_quantity INT,
  unit TEXT DEFAULT 'un',
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- 10. PRODUCT ADDONS
CREATE TABLE public.product_addons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
  group_name TEXT NOT NULL DEFAULT 'Adicionais',
  name TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  is_required BOOLEAN DEFAULT false,
  max_select INT DEFAULT 1,
  sort_order INT DEFAULT 0
);
ALTER TABLE public.product_addons ENABLE ROW LEVEL SECURITY;

-- 11. CARTS
CREATE TABLE public.carts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, store_id)
);
ALTER TABLE public.carts ENABLE ROW LEVEL SECURITY;

-- 12. CART ITEMS
CREATE TABLE public.cart_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cart_id UUID REFERENCES public.carts(id) ON DELETE CASCADE NOT NULL,
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL,
  addons JSONB DEFAULT '[]',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;

-- 13. ORDERS
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  store_id UUID REFERENCES public.stores(id) NOT NULL,
  address_id UUID REFERENCES public.addresses(id),
  status order_status NOT NULL DEFAULT 'pending',
  subtotal DECIMAL(10,2) NOT NULL,
  delivery_fee DECIMAL(10,2) DEFAULT 0,
  discount DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) NOT NULL,
  payment_method payment_method,
  notes TEXT,
  is_pickup BOOLEAN DEFAULT false,
  estimated_delivery_min INT,
  coupon_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- 14. ORDER ITEMS
CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE NOT NULL,
  product_id UUID REFERENCES public.products(id) NOT NULL,
  product_name TEXT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL,
  addons JSONB DEFAULT '[]',
  notes TEXT
);
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

-- 15. DELIVERIES
CREATE TABLE public.deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE NOT NULL UNIQUE,
  driver_id UUID REFERENCES auth.users(id),
  status delivery_status NOT NULL DEFAULT 'pending',
  pickup_time TIMESTAMPTZ,
  delivery_time TIMESTAMPTZ,
  driver_lat DOUBLE PRECISION,
  driver_lng DOUBLE PRECISION,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

-- 16. COUPONS
CREATE TABLE public.coupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  description TEXT,
  discount_type discount_type NOT NULL DEFAULT 'percentage',
  discount_value DECIMAL(10,2) NOT NULL,
  min_order_value DECIMAL(10,2) DEFAULT 0,
  max_uses INT,
  used_count INT DEFAULT 0,
  store_id UUID REFERENCES public.stores(id),
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;

-- 17. PAYMENTS
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  method payment_method NOT NULL,
  status payment_status NOT NULL DEFAULT 'pending',
  transaction_id TEXT,
  pix_code TEXT,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- 18. REVIEWS
CREATE TABLE public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE NOT NULL,
  store_id UUID REFERENCES public.stores(id) NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  rating INT NOT NULL,
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- 19. FAVORITES
CREATE TABLE public.favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, store_id)
);
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;

-- ============================================
-- HELPER FUNCTIONS (SECURITY DEFINER)
-- ============================================

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'admin')
$$;

CREATE OR REPLACE FUNCTION public.is_store_owner(_store_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.stores WHERE id = _store_id AND owner_id = auth.uid()
  )
$$;

CREATE OR REPLACE FUNCTION public.get_store_id_for_product(_product_id UUID)
RETURNS UUID
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT store_id FROM public.products WHERE id = _product_id LIMIT 1
$$;

-- ============================================
-- TRIGGERS
-- ============================================

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER trg_stores_updated BEFORE UPDATE ON public.stores FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER trg_products_updated BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER trg_orders_updated BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER trg_deliveries_updated BEFORE UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER trg_carts_updated BEFORE UPDATE ON public.carts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''));
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'customer');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================
-- RLS POLICIES
-- ============================================

-- Profiles
CREATE POLICY "Users read own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id OR public.is_admin());
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id OR public.is_admin());

-- User Roles
CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT USING (auth.uid() = user_id OR public.is_admin());
CREATE POLICY "Admin manage roles" ON public.user_roles FOR ALL USING (public.is_admin());

-- City Service Areas (public read)
CREATE POLICY "Anyone can read areas" ON public.city_service_areas FOR SELECT USING (true);
CREATE POLICY "Admin manage areas" ON public.city_service_areas FOR ALL USING (public.is_admin());

-- Addresses
CREATE POLICY "Users manage own addresses" ON public.addresses FOR ALL USING (auth.uid() = user_id OR public.is_admin());

-- Categories (public read)
CREATE POLICY "Anyone can read categories" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Admin manage categories" ON public.categories FOR ALL USING (public.is_admin());

-- Stores
CREATE POLICY "Public read approved stores" ON public.stores FOR SELECT USING (
  (is_active = true AND is_approved = true) OR owner_id = auth.uid() OR public.is_admin()
);
CREATE POLICY "Owner insert store" ON public.stores FOR INSERT WITH CHECK (owner_id = auth.uid() OR public.is_admin());
CREATE POLICY "Owner update store" ON public.stores FOR UPDATE USING (owner_id = auth.uid() OR public.is_admin());
CREATE POLICY "Admin delete store" ON public.stores FOR DELETE USING (public.is_admin());

-- Store Hours
CREATE POLICY "Read store hours" ON public.store_hours FOR SELECT USING (true);
CREATE POLICY "Owner manage hours" ON public.store_hours FOR ALL USING (
  public.is_store_owner(store_id) OR public.is_admin()
);

-- Products
CREATE POLICY "Public read products" ON public.products FOR SELECT USING (true);
CREATE POLICY "Owner manage products" ON public.products FOR INSERT WITH CHECK (public.is_store_owner(store_id) OR public.is_admin());
CREATE POLICY "Owner update products" ON public.products FOR UPDATE USING (public.is_store_owner(store_id) OR public.is_admin());
CREATE POLICY "Owner delete products" ON public.products FOR DELETE USING (public.is_store_owner(store_id) OR public.is_admin());

-- Product Addons
CREATE POLICY "Public read addons" ON public.product_addons FOR SELECT USING (true);
CREATE POLICY "Owner manage addons" ON public.product_addons FOR ALL USING (
  public.is_store_owner(public.get_store_id_for_product(product_id)) OR public.is_admin()
);

-- Carts
CREATE POLICY "Users manage own cart" ON public.carts FOR ALL USING (auth.uid() = user_id OR public.is_admin());

-- Cart Items
CREATE POLICY "Users manage own cart items" ON public.cart_items FOR ALL USING (
  EXISTS (SELECT 1 FROM public.carts WHERE id = cart_id AND user_id = auth.uid()) OR public.is_admin()
);

-- Orders
CREATE POLICY "Read own orders" ON public.orders FOR SELECT USING (
  user_id = auth.uid() OR public.is_store_owner(store_id) OR public.is_admin()
);
CREATE POLICY "Create own orders" ON public.orders FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "Update orders" ON public.orders FOR UPDATE USING (
  user_id = auth.uid() OR public.is_store_owner(store_id) OR public.is_admin()
);

-- Order Items
CREATE POLICY "Read own order items" ON public.order_items FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.orders WHERE id = order_id AND (user_id = auth.uid() OR public.is_store_owner(store_id) OR public.is_admin()))
);
CREATE POLICY "Insert order items" ON public.order_items FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.orders WHERE id = order_id AND user_id = auth.uid())
);

-- Deliveries
CREATE POLICY "Read deliveries" ON public.deliveries FOR SELECT USING (
  driver_id = auth.uid() OR
  EXISTS (SELECT 1 FROM public.orders WHERE id = order_id AND (user_id = auth.uid() OR public.is_store_owner(store_id))) OR
  public.is_admin()
);
CREATE POLICY "Driver update delivery" ON public.deliveries FOR UPDATE USING (driver_id = auth.uid() OR public.is_admin());
CREATE POLICY "Admin manage deliveries" ON public.deliveries FOR ALL USING (public.is_admin());

-- Coupons (public read active)
CREATE POLICY "Read active coupons" ON public.coupons FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "Admin manage coupons" ON public.coupons FOR ALL USING (public.is_admin());

-- Payments
CREATE POLICY "Read own payments" ON public.payments FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.orders WHERE id = order_id AND (user_id = auth.uid() OR public.is_store_owner(store_id))) OR public.is_admin()
);
CREATE POLICY "Create payment" ON public.payments FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.orders WHERE id = order_id AND user_id = auth.uid()) OR public.is_admin()
);

-- Reviews
CREATE POLICY "Read reviews" ON public.reviews FOR SELECT USING (true);
CREATE POLICY "Create review" ON public.reviews FOR INSERT WITH CHECK (user_id = auth.uid());

-- Favorites
CREATE POLICY "Users manage favorites" ON public.favorites FOR ALL USING (auth.uid() = user_id);

-- ============================================
-- REALTIME
-- ============================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.deliveries;

-- ============================================
-- SEED DATA
-- ============================================

-- City service area
INSERT INTO public.city_service_areas (city_name, state, neighborhoods, zip_codes, center_lat, center_lng, radius_km)
VALUES ('Serra Caiada', 'RN', ARRAY['Centro', 'Alto da Liberdade', 'São José', 'Nova Descoberta', 'Boa Vista', 'Alto Bonito'], ARRAY['59245-000'], -6.1053, -35.7133, 15);

-- Categories
INSERT INTO public.categories (name, slug, icon, mode, sort_order) VALUES
  ('Restaurantes', 'restaurantes', '🍽️', 'food', 1),
  ('Lanches', 'lanches', '🍔', 'food', 2),
  ('Pizzas', 'pizzas', '🍕', 'food', 3),
  ('Açaí', 'acai', '🍇', 'food', 4),
  ('Doces', 'doces', '🍰', 'food', 5),
  ('Mercado', 'mercado', '🛒', 'market', 6),
  ('Farmácia', 'farmacia', '💊', 'market', 7),
  ('Bebidas', 'bebidas', '🍺', 'market', 8),
  ('Pet', 'pet', '🐾', 'market', 9),
  ('Conveniência', 'conveniencia', '🏪', 'market', 10),
  ('Água/Gás', 'agua-gas', '🔥', 'market', 11);
