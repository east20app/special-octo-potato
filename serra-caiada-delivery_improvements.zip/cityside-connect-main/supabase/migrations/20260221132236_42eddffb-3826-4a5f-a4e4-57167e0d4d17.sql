
-- Create driver_applications table
CREATE TABLE public.driver_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  full_name text NOT NULL DEFAULT '',
  phone text,
  document text,
  vehicle text DEFAULT 'moto',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  rejection_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE public.driver_applications ENABLE ROW LEVEL SECURITY;

-- Users can read their own application
CREATE POLICY "Users read own application"
ON public.driver_applications FOR SELECT
USING (auth.uid() = user_id OR public.is_admin());

-- Users can insert their own application
CREATE POLICY "Users insert own application"
ON public.driver_applications FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can update their own pending application
CREATE POLICY "Users update own pending application"
ON public.driver_applications FOR UPDATE
USING (auth.uid() = user_id AND status = 'pending');

-- Admin can do everything
CREATE POLICY "Admin manage applications"
ON public.driver_applications FOR ALL
USING (public.is_admin());

-- Trigger for updated_at
CREATE TRIGGER update_driver_applications_updated_at
BEFORE UPDATE ON public.driver_applications
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
